# Introduction

Consumer of the CTR / Agent event / Contact Flow logs streamed to s3.
This function would be the consumer of the buckets with "raw" in the middle of its name.

Samples of each types of file are included in the `test/sample-events` folder.

# Build and Test

This function is intended to be build and tested in ADO environment.

# Function Components and Logic:

## Handler (`index.mjs`)

The function will be triggered by the event emitted by S3 when objects are created to specific buckets listed in the environment variables. Currently, 4 buckets were listened by the function, they are:

- S3_BUCKET_AGENT_EVENTS: `{region}-connect-agent-events-raw-{env}-s3`
- S3_BUCKET_CLOUDWATCH_LOGS: `{region}-cloudwatch-logs-raw-{env}-s3`
- S3_BUCKET_CTR: `{region}-connect-ctr-raw-{env}-s3`
- S3_BUCKET_EXPORT_REPORTS: `{region}-connect-exported-reports-{env}-s3`

In future, the Evaluation forms bucket needed to be accessed as well.

The database connection is created out-side of the main handler, with a lazy initialization to save time between invocations and reuse resource as much as possible.

The handler, when received an event, will determine the type of the invocation by its originating S3 bucket and distribute to the right handlers.

## Agent Events handling (`update-agent-event.mjs`)

TODO: Update agent event handling here.

## CTR Events handling (`update-ctr.mjs`)

TODO: Update CTR event handling here.

## Scheduled Reports handling (`update-scheduled-reports.mjs`)

Currently, there are 4 scheduled reports needed to be handled by ODS:

- `ODS_AgentHier1`
- `ODS_AgentQueue`
- `ODS_Queue`
- `ODS_RoutingProfile`

They need to be scheduled and saved manually in each stage. Their definition can be found in the following section of Enterprise Voice space in Confluence: [https://geicoit.atlassian.net/wiki/spaces/AZCN/pages/38253855096/region+-s3-update-ods-+env+-lm#Scheduled-Reports%3A] (Will migrate later.)

After provisioning, the CSVs needed to be downloaded to the Lambda container and processed there.

Due to the nature of how the CSVs are generated, the headers may change (for example, different name of the first level hierarchy, or added custom status, will trigger a new column to be added in the csv.), and some values might be null (for example, the aggregated agent and queue table may have agent value as null, as the customer can be reached to a queue and disconnect.). Therefore, it's impossible to configure primary key(s) for those tables.

In the meantime, if a table is configured without a primary key, we have potentially another issue of ingesting a file multiple times due to lack of the primary keys to prevent duplication to happen.

To address this, a new table of `ods_oob_csv_processing_record` is created to act as a lock/semaphore to prevent a file to be processed twice.

```SQL
CREATE TABLE ods_oob_csv_processing_record(
    -- this table is used to track if a file had been processed or not, and preventing
    -- same file being inserted multiple times
    s3_key_name varchar,
    processing_status varchar NOT NULL,
    -- ENUM ("SUCCEEDED", "FAILED", "PROCESSING")
    PRIMARY KEY (s3_key_name)
);
```

The logic to insert the lines would be the following:

```js
try {
  await db_client.query("INSERT INTO ods_oob_csv_processing_record VALUES ('s3_file_name', 'PROCESSING');");
} catch (error) {
  exit(); // this record is present, we shouldn't processing it.
}
try {
  await db_client.query("BEGIN;");
  await db_client.query("INSERT INTO table VALUES (first_line);");
  // .. loop all lines
  await db_client.query("INSERT INTO table VALUES (last line);");
  // State change to succeeded only when this commit succeeds. 
  await db_client.query("INSERT INTO ods_oob_csv_processing_record VALUES ('s3_file_name', 'SUCCEEDED');");
  await db_client.query("COMMIT;");
} catch (error) {
  await db_client.query("ROLLBACK;");
  await db_client.query("INSERT INTO ods_oob_csv_processing_record VALUES ('s3_file_name', 'FAILED');");
}
```



##

# TODOs

1. Handling the errors. Currently the exceptions started with `Unexpected data format: ${REASON}` is all embedded with the cause of the error. This can be used to trigger the error handling with minimal data size that can be handled by a SQS queue. (256KB)
