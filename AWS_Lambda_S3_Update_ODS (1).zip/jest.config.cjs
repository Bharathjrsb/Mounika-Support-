const config = {
    testRegex: 'tests/.*\.test\.js$',
    transform: {}
};

module.exports = config;