import logplease from "logplease";
import { S3Client, GetObjectCommand } from "@aws-sdk/client-s3";

import dbInit from "./util/configure-db-client.mjs";
import updateCTR from "./update-ctr.mjs";
import updateAgentEvent from "./update-agent-event.mjs";
import updateScheduledReportEvent from "./update-scheduled-reports.mjs";
import updateEvalForms from "./update-evaluation-forms.mjs";

import process from "node:process";

const logger = logplease.create("Logger", { showTimestamp: false, useColors: false });
logplease.setLogLevel(process.env.AWS_LAMBDA_LOGGING_LEVEL);

// Configure db client
const db_client = await dbInit();

process.on("SIGTERM", async () => {
  logger.debug("Container shutdown handler was called.");
  await db_client.end();
  logger.info("Successfully disconnected DB client.");
  process.exit();
});

export const handler = async (event, context) => {
  logger.info("S3 Update to ODS Lambda invoked");
  logger.debug(`RAW EVENT: ${JSON.stringify(event)}`);

  let lambda_res;

  try {
    // Create S3 instance

    // Verify if this event is from Eventbridge.

    if (!(event.source === "aws.s3" && event["detail-type"] === "Object Created")) {
      return {
        LambdaSuccess: false,
        message: `Eventbridge event type unmatched: event.source=${event.source}, event.detail-type=${event["detail-type"]}`,
      };
    }
    logger.debug(`Eventbridge event type matched: event.source=${event.source}, event.detail-type=${event["detail-type"]}`);

    const s3Client = new S3Client();

    const s3_key_name = decodeURIComponent(event.detail.object.key);
    const s3_bucket_name = event.detail.bucket.name;
    logger.info(`Processing ${s3_bucket_name}/${s3_key_name}`);
    // Get object from S3
    let command = new GetObjectCommand({
      Bucket: s3_bucket_name,
      Key: s3_key_name,
    });

    logger.info(`Downloading ${s3_bucket_name}/${s3_key_name}`);
    let s3Response = await s3Client.send(command);
    logger.info(`Successfully downloaded ${s3_bucket_name}/${s3_key_name}`);

    let body = await s3Response.Body.transformToString("utf8");
    let data;
    // some inputs are json format where some are csv inputs.
    switch (s3_bucket_name) {
      case process.env.S3_BUCKET_CTR:
      case process.env.S3_BUCKET_AGENT_EVENTS:
      case process.env.S3_BUCKET_CLOUDWATCH_LOGS:
      case process.env.S3_BUCKET_EVALUATION_FORMS:
        // Cases for json inputs.
        try {
          data = await JSON.parse(body);
        } catch (error) {
          logger.info(`Error parsing file ${s3_bucket_name}/${s3_key_name}, trying to fix the file.`);
          // Temporary fixing issues with some agent event files.
          try {
            data = await JSON.parse(`[` +body.replaceAll(`}{`, `},{`) + `]`);
            logger.info(`Fixed the error while parsing ${s3_bucket_name}/${s3_key_name}.`);
          } catch (error) {
            logger.error(`Error parsing file ${s3_bucket_name}/${s3_key_name}. Cannot fix the file.`);
            error.s3Location = `${s3_bucket_name}/${s3_key_name}`;
            throw error;
          }
        }
        logger.info(`Parsing complete.`);
        break;
      case process.env.S3_BUCKET_EXPORT_REPORTS:
        data = s3Response.Body;
        break;
      default:
        throw new Error(`Unknown bucket source ${s3_bucket_name}.`);
        break;
    }

    //This data should be an array for most of the data structure.

    // Determine which S3 bucket called lambda and route accordingly
    switch (s3_bucket_name) {
      case process.env.S3_BUCKET_CTR:
        logger.info(`Incoming CTR Events.`);
        lambda_res = await updateCTR(data, s3_key_name, db_client);
        break;

      case process.env.S3_BUCKET_AGENT_EVENTS:
        logger.info(`Incoming Agent Events.`);
        lambda_res = await updateAgentEvent(data, s3_key_name, db_client);
        break;

      case process.env.S3_BUCKET_CLOUDWATCH_LOGS:
        logger.info(`Incoming Cloudwatch Events.`);
        logger.info(`Not implemented => Cloudwatch Events`);
        //throw new Error(`Not implemented => Cloudwatch Events`);
        break;

      case process.env.S3_BUCKET_EXPORT_REPORTS:
        logger.info(`Incoming Exported Reports.`);
        lambda_res = await updateScheduledReportEvent(data, s3_key_name, db_client);
        break;

      case process.env.S3_BUCKET_EVALUATION_FORMS:
        logger.info(`Incoming Evaluation Forms.`);
        lambda_res = await updateEvalForms(data, s3_key_name, db_client);
        break;

      default:
        logger.error(`Unexpected data format: S3`);
        logger.error(`s3IndividualEvent = ${console.log(s3_key_name)}`);
        throw new Error(`Unexpected data format: S3`, { s3_bucket_name: s3_bucket_name, s3_key_name: s3_key_name });
    }
  } catch (error) {
    // we want to filter specific errors so they won't register as errors in cloudwatch metric.
    // But will let other errors to be thrown so it's reflected in the metric.
    switch (error.message) {
      case "Not implemented => Cloudwatch Events":
        logger.info(`Ignoring ${error.message}`);
        break;
      default:
        // throw the error. Build the Error message so the log can be downloaded easily. It will be sent to the SNS in the future as well.
        const region = process.env.AWS_REGION;
        const logGroupName = process.env.AWS_LAMBDA_LOG_GROUP_NAME;
        const logStreamName = process.env.AWS_LAMBDA_LOG_STREAM_NAME;
        const requestId = context.awsRequestId;
        // I hope no-one need to do this in the future..
        const cwUrl =
          `https://${region}.console.aws.amazon.com/cloudwatch/home?region=${region}#logsV2:log-groups/log-group/` +
          `${encodeURIComponent(encodeURIComponent(logGroupName)).replaceAll("%", "$")}` +
          `/log-events/` +
          `${encodeURIComponent(encodeURIComponent(logStreamName)).replaceAll("%", "$")}` +
          `${encodeURIComponent("?filterPattern=").replaceAll("%", "$")}` +
          `${encodeURIComponent(encodeURIComponent("%" + requestId + "%")).replaceAll("%", "$")}`;
        error.message = error.message + `cwUrl= ${cwUrl}`;
        logger.error(`UNHANDLED_ERROR: ${error.message}`);
        throw error;
    }
    lambda_res = {
      LambdaSuccess: false,
      message: error.message,
    };
  }
  logger.debug("Lambda Response: " + JSON.stringify(lambda_res));
  return lambda_res;
};
