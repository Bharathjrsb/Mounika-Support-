import logplease from "logplease";
import { flattenHierarchy } from "./util/misc.mjs";

// Configure logger
const logger = logplease.create("Logger", {
  showTimestamp: false,
  useColors: false,
});
logplease.setLogLevel(process.env.AWS_LAMBDA_LOGGING_LEVEL);

const AGENT_EVENTS_TABLE_NAME = "fact_agent_event_snapshots";
const TODO = null;

/**
 * Flatten the concurrency array to a human-readable field
 * @param {Object} concurrencyArray The array of object $.CurrentAgentSnapshot.Configuration.RoutingProfile.Concurrency
 * @returns JSON String of the Concurrency Array with VOICE channel at the first item.
 */
export function flattenConcurrency(concurrencyArray) {
  if (!Array.isArray(concurrencyArray) || concurrencyArray.length === 0) {
    return "";
  }
  // following function will sort the concurrency bubbles the VOICE to the first and keep the rest the same
  concurrencyArray.sort((a, b) => {
    if (a.Channel === "VOICE") {
      return -1;
    } else if (b.Channel === "VOICE") {
      return 1;
    } else {
      return 0;
    }
  });
  return JSON.stringify(concurrencyArray);
}

/**
 * Flatten the proficiency array to a human-readable field
 * @param {Object} proficiencyArray The array of object $.CurrentAgentSnapshot.Configuration.Proficiencies
 * this helps in determining the proficiency level for an agent.
 */
export function flattenProficiency(proficiencyArray) {
  if (!Array.isArray(proficiencyArray) || proficiencyArray.length === 0) {
    return "";
  }
  
  return JSON.stringify(proficiencyArray);
}

/**
 * Given 2 timestamps, pick the most recent one, and return the timestamp in ISO8601, to be inserted to the database.
 * @param {String} ts1 String timestamp 1
 * @param {String} ts2 String timestamp 2
 */
export function getSnapshotTimestamp(ts1, ts2) {
  let t_ts1 = new Date(ts1);
  let t_ts2 = new Date(ts2);

  if (!isNaN(t_ts1) && !isNaN(t_ts2)) {
    return t_ts1 >= t_ts2 ? t_ts1.toISOString() : t_ts2.toISOString();
  } else if (!isNaN(t_ts1)) {
    return t_ts1.toISOString();
  } else if (!isNaN(t_ts2)) {
    return t_ts2.toISOString();
  }
  throw new Error(`getSnapshotTimestamp() invalid input(s): ts1 = ${ts1}, ts2 = ${ts2}`);
}

/**
 * This function handles the events with state changes.
 * Currently the design of this function will take each contact from the $.CurrentAgentSnapshot.Contacts
 * array to be inserted as individual state changes.
 * @param {Object} agentEvent the Agent event object
 * @returns {Object} list of the state change queries.
 */
export async function handleStateChange(agentEvent) {
  logger.debug(`Entering handleStateChange`);
  let currentSnapshot = agentEvent.CurrentAgentSnapshot;
  logger.debug(JSON.stringify(agentEvent));
  try {
    logger.debug(`currentSnapshot.Contacts.length = ${currentSnapshot.Contacts.length}`);
    let valuesString;
    let columnString;
    let results = { insert: true, queries: [] };

    // Build the mapper assuming there's no associated contact to this snapshot.
    let aeMapper = {
      username: currentSnapshot.Configuration.Username,
      agent_arn: agentEvent.AgentARN,
      event_type: agentEvent.EventType,
      // snapshot_timestamp defined as the later of (CurrentAgentSnapshot.StartTimestamp, or Contacts[].StateStartTimestamp )
      snapshot_timestamp: currentSnapshot.AgentStatus.StartTimestamp,
      agent_status_arn: currentSnapshot.AgentStatus.ARN,
      agent_status_name: currentSnapshot.AgentStatus.Name,
      agent_status_type: currentSnapshot.AgentStatus.Type,
      agent_status_start_timestamp: currentSnapshot.AgentStatus.StartTimestamp,
      configuration_agent_hierarchy_groups: flattenHierarchy(currentSnapshot.Configuration.AgentHierarchyGroups),
      configuration_auto_accept: currentSnapshot.Configuration.AutoAccept,
      configuration_first_name: currentSnapshot.Configuration.FirstName,
      configuration_language_code: currentSnapshot.Configuration.LanguageCode,
      configuration_last_name: currentSnapshot.Configuration.LastName,
      configuration_proficiencies: flattenProficiency(currentSnapshot.Configuration.Proficiencies),
      configuration_sip_address: currentSnapshot.Configuration.SipAddress,
      configuration_routing_profile_arn: currentSnapshot.Configuration.RoutingProfile.ARN,
      configuration_routing_profile_name: currentSnapshot.Configuration.RoutingProfile.Name,
      configuration_routing_profile_concurrency: flattenConcurrency(currentSnapshot.Configuration.RoutingProfile.Concurrency),
      configuration_routing_profile_default_outbound_queue_name: currentSnapshot.Configuration.RoutingProfile.DefaultOutboundQueue.Name,
      configuration_routing_profile_default_outbound_queue_channels: currentSnapshot.Configuration.RoutingProfile.DefaultOutboundQueue.Channels.join(","),
      configuration_routing_profile_inbound_queues: currentSnapshot.Configuration.RoutingProfile.InboundQueues.map((a) => a.Name).join(","),
      contact_channel: null,
      contact_connected_to_agent_timestamp: null,
      contact_contact_id: null,
      contact_initial_contact_id: null,
      contact_initiation_method: null,
      contact_queue_name: null,
      contact_queue_timestamp: null,
      contact_state: null,
      contact_state_start_timestamp: null,
      agent_event_version: agentEvent.Version,
    };

    if (!columnString) {
      columnString = Object.keys(aeMapper).join(",");
      let _i = 1;
      valuesString = Object.values(aeMapper)
        .map(() => "$" + _i++)
        .join(",");
    }

    if (currentSnapshot.Contacts.length > 0) {
      // received contacts in this snapshots, loop through the contacts and add them into the ods
      for (let idx = 0; idx < currentSnapshot.Contacts.length; idx++) {
        aeMapper.snapshot_timestamp = getSnapshotTimestamp(currentSnapshot.AgentStatus.StartTimestamp, currentSnapshot.Contacts[idx].StateStartTimestamp);
        aeMapper.contact_channel = currentSnapshot.Contacts[idx].Channel;
        aeMapper.contact_connected_to_agent_timestamp = currentSnapshot.Contacts[idx].ConnectedToAgentTimestamp;
        aeMapper.contact_contact_id = currentSnapshot.Contacts[idx].ContactId;
        aeMapper.contact_initial_contact_id = currentSnapshot.Contacts[idx].InitialContactId;
        aeMapper.contact_initiation_method = currentSnapshot.Contacts[idx].InitiationMethod;
        aeMapper.contact_queue_name = currentSnapshot.Contacts[idx].Queue.Name;
        aeMapper.contact_queue_timestamp = currentSnapshot.Contacts[idx].QueueTimestamp;
        aeMapper.contact_state = currentSnapshot.Contacts[idx].State;
        aeMapper.contact_state_start_timestamp = currentSnapshot.Contacts[idx].StateStartTimestamp;

        results.queries.push({
          text: `INSERT INTO ${AGENT_EVENTS_TABLE_NAME} (${columnString})
                    VALUES (${valuesString})
                    ON CONFLICT DO NOTHING
                    RETURNING snapshot_timestamp;`,
          values: Object.values(aeMapper),
        });
      }
    } else {
      results.queries.push({
        text: `INSERT INTO ${AGENT_EVENTS_TABLE_NAME} (${columnString})
                VALUES (${valuesString})
                ON CONFLICT DO NOTHING
                RETURNING snapshot_timestamp;`,
        values: Object.values(aeMapper),
      });
    }
    return results;
  } catch (error) {
    error.cause = agentEvent;
    throw error;
  }
}

/**
 * Parse Agent Event data and push it to ODS DB.
 * @param {object[]} data: The parsed object for the s3 object downloaded in the handler
 * @param {String} : The S3 key name for this event.
 * @param {pg.Client} db_client: Database client to push data.
 */
export default async function updateAgentEvent(data, s3_key_name, db_client) {
  logger.info("Attempting to update ODS based on Agent Event bucket event...");
  let lambdaResult = {
    LambdaSuccess: false,
    message: "",
  };

  /**
   * The Agent event update logic is much more complex than CTR logic. The single event
   * from Agent event stream (if we ignore the "HEART_BEAT" events) is tracking a changing
   * edge of status - it contains a PreviousAgentSnapshot and a CurrentAgentSnapshot.
   * This function will only try to insert the CurrentAgentSnapshot and ignore the
   * PreviousAgentSnapshot to simplify the process.
   *
   * Important to understand: The status of an agent needed to be determined by both
   * Agent status and contact status, which is independent with each other mostly. The
   * Agent status is the Available/offline etc, however the contact status is about
   * Connecting/Connected/MissedCall. Any of the changes from both sources can trigger
   * a new agent event being issued. We need to track both, therefore, ideally the table
   * need to have both info as the primary key and therefore we can distinguish them.
   * but agent can be idle without a contact, which makes making contact info as primary key
   * unfeasible.
   *
   * The compromise for this situation is that when we receive a CurrentAgentSnapshot
   * The CurrentAgentSnapshot will use the event's timestamp to track as the current
   * event's time, or the agent status's start timestamp, whichever is later.
   *
   * For normal Status change events that comes with a contact, the later of the agent
   * status start timestamp or the contact state start timestamp shall be used.
   *
   */
  try {
    await db_client.tryConnect();
    logger.info("Successfully connected DB client.");

    // Unpack the data from array to events.
    if (Array.isArray(data) || data.EventType !== undefined) {
      // Convert the data to a array to be processed, in case the previous processor send me a single event.
      if (data.EventType !== undefined) {
        data = [data];
      }
      let eventPromises = data.map(async (agentEvent) => {
        // Check event type. EventType = (STATE_CHANGE | HEART_BEAT | LOGIN | LOGOUT)
        switch (agentEvent.EventType) {
          /**
           * in this place we run the events through concurrently and ignore the heartbeats but take
           * the login and logout and state_change into consideration.
           */
          case "HEART_BEAT":
            // We ignore the heart beats since state change didn't occur.
            return { insert: false };
          case "LOGIN":
          case "LOGOUT":
          case "STATE_CHANGE":
            return await handleStateChange(agentEvent);
          default:
            throw new Error(`Unexpected data format: AgentEvent.EventType ${agentEvent.EventType}`, { cause: agentEvent });
        }
      });

      let mappingResult = await Promise.allSettled(eventPromises);
      // list of promises rejected (need to bubble up to retry.)
      let mappingFailures = [];
      // TODO: In future, these rejected items should be sent to retry.
      // list of promises fulfilled and to be inserted as well
      let toBeInserted = [];
      mappingResult.forEach((item) => {
        if (item.status === "rejected") {
          // Push the reason of rejection
          mappingFailures.push(item.reason);
        } else if (item.status === "fulfilled" && item.value.insert === true) {
          toBeInserted.push(item.value.queries);
        }
      });
      // Finished building all queries.
      // Flatten the incoming table - previously the tobeinserted array is a array of arrays.
      toBeInserted = toBeInserted.flat();
      logger.info(
        `${mappingResult.length} entries in total, ${toBeInserted.length} entries to be inserted, ${mappingFailures.length} entries cannot be parsed.`
      );
      if (toBeInserted.length > 0) {
        let insertResult = await Promise.allSettled(toBeInserted.map(async (item) => db_client.query(item)));
        let insertCount = 0;
        let insertFailureReasons = [];
        insertResult.forEach((item) => {
          if (item.status === "fulfilled") {
            insertCount += item.value.rowCount;
          } else {
            insertFailureReasons.push(JSON.stringify(item.reason));
          }
        });
        logger.info(`Inserted ${insertCount} entries out of ${toBeInserted.length}. ${insertFailureReasons.length} insert failures.`);
        if (insertFailureReasons.length > 0) {
          logger.error(`insertFailureReasons=${JSON.stringify(insertFailureReasons)}`)
          throw new Error(`Database Insert failures: Agent Events`, {
            cause: insertFailureReasons,
          });
        }
      } else {
        logger.info(`No agent event entry to be inserted in this session.`);
      }

      if (mappingFailures.length > 0) {
        // TODO: This should be related to the effort to build a retry mechanism.
        logger.debug(mappingFailures);
        logger.info(`Agent Event Insert partially successful.`);
        lambdaResult.LambdaSuccess = true;
        lambdaResult.message = `Agent Event Insert partially successful.`;
      } else {
        logger.info(`Agent Event Insert successful.`);
        lambdaResult.LambdaSuccess = true;
        lambdaResult.message = `Agent Event Insert successful.`;
      }
    } else {
      throw new Error(`Unexpected data format: Agent Events`, { cause: data });
    }
    return lambdaResult;
  } catch (error) {
    logger.error(error.message);
    logger.error(error.stack);
    throw error;
  }
}
