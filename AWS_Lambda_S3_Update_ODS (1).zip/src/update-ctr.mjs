import logplease from "logplease";
import { isoStringToSQLTime, isoStringTimeDiff, safeAccessObject, flattenHierarchy, insertValue } from "./util/misc.mjs";
// Configure logger
const logger = logplease.create("Logger", { showTimestamp: false, useColors: false });
logplease.setLogLevel(process.env.AWS_LAMBDA_LOGGING_LEVEL);

const CTR_TABLE_NAME = "fact_ctr";
const CTR_ATTRIBUTES_TABLE_NAME = "ctr_attributes";
const CTR_RECORDINGS_TABLE_NAME = "ctr_recordings";
const ATTRIBUTES_FLATTENED_TABLE_NAME = "ctr_attributes_ods";
const CTR_AUDIO_QUALITY_TABLE_NAME = "fact_audio_quality_metrics";
const ATTRIBUTES_PATTERN = process.env.ATTRIBUTES_PATTERN;
const ATTRIBUTES_PATTERN_DEFAULT = ["-ods-", "ods-", "-ods", "sfdc-", "ccb_", "CCB", "ccp-", "-ccp-", "-ccp"];

/**
 * Convert a raw CTR object to a SQL query to insert data to table for ctr itself.
 * @param {*} rawCtr Parsed CTR object, with AWSAccountId as a direct property.
 * @returns {Object} result: a postgresql prepared statement object that can be reused. https://node-postgres.com/features/queries#prepared-statements
 */
export function ctrQueryConstructor(rawCtr) {
  /**
   * Translation table of the CTR to schema of fact_ctr
   * Ref: https://docs.aws.amazon.com/connect/latest/adminguide/ctr-data-model.html
   */
  const ctrMapper = {
    contact_id: rawCtr.ContactId,
    last_update_timestamp: isoStringToSQLTime(rawCtr.LastUpdateTimestamp),
    aws_account_id: rawCtr.AWSAccountId,
    aws_contact_trace_record_format_version: rawCtr.AWSContactTraceRecordFormatVersion,
    queue_name: safeAccessObject(rawCtr, "Queue.Name"),
    routing_profile_name: safeAccessObject(rawCtr, "Agent.RoutingProfile.Name"),
    channel_name: rawCtr.Channel,
    initiation_method: rawCtr.InitiationMethod,
    mediastream_type: Array.isArray(rawCtr.MediaStreams) ? rawCtr.MediaStreams[0].Type : null, // get the first result.
    disconnect_reason: rawCtr.DisconnectReason,
    username: safeAccessObject(rawCtr, "Agent.Username"),
    agent_hierarchy_id: flattenHierarchy(safeAccessObject(rawCtr, "Agent.HierarchyGroups")),
    acw_duration: safeAccessObject(rawCtr, "Agent.AfterContactWorkDuration"),
    agent_connection_attempts: rawCtr.AgentConnectionAttempts,
    acw_end_timestamp: isoStringToSQLTime(safeAccessObject(rawCtr, "Agent.AfterContactWorkEndTimestamp")),
    acw_start_timestamp: isoStringToSQLTime(safeAccessObject(rawCtr, "Agent.AfterContactWorkStartTimestamp")),
    agent_arn: safeAccessObject(rawCtr, "Agent.ARN"),
    longest_hold_duration: safeAccessObject(rawCtr, "Agent.LongestHoldDuration"),
    agent_interaction_duration: safeAccessObject(rawCtr, "Agent.AgentInteractionDuration"),
    cust_hold_duration: safeAccessObject(rawCtr, "Agent.CustomerHoldDuration"),
    initial_contact_id: rawCtr.InitialContactId,
    initiation_timestamp: isoStringToSQLTime(rawCtr.InitiationTimestamp),
    related_contact_id: rawCtr.RelatedContactId,
    transfer_completed_timestamp: isoStringToSQLTime(rawCtr.TransferCompletedTimestamp),
    transferred_to_endpoint: safeAccessObject(rawCtr, "TransferredToEndpoint.Address"), // TODO - maybe we need another extra address / type flattening?
    external_third_party_interaction_duration: safeAccessObject(rawCtr, "ExternalThirdParty.ExternalThirdPartyInteractionDuration"), // TODO - cannot find the position on this data.
    contact_handle_duration: isoStringTimeDiff(rawCtr.ConnectedToSystemTimestamp, rawCtr.DisconnectTimestamp), // Assume it's the previous "contact_handle_time" which is defined as ConnectedToSystemTimestamp-DisconnectTimestamp
    contact_on_hold_count: safeAccessObject(rawCtr, "Agent.NumberOfHolds"),
    queue_duration: safeAccessObject(rawCtr, "Queue.Duration"),
    cust_endpoint_address: safeAccessObject(rawCtr, "CustomerEndpoint.Address"),
    customer_endpoint_type: safeAccessObject(rawCtr, "CustomerEndpoint.Type"),
    enqueue_timestamp: isoStringToSQLTime(safeAccessObject(rawCtr, "Queue.EnqueueTimestamp")),
    dequeue_timestamp: isoStringToSQLTime(safeAccessObject(rawCtr, "Queue.DequeueTimestamp")),
    connected_to_agent_timestamp: isoStringToSQLTime(safeAccessObject(rawCtr, "Agent.ConnectedToAgentTimestamp")),
    connected_to_system_timestamp: isoStringToSQLTime(rawCtr.ConnectedToSystemTimestamp),
    disconnect_timestamp: isoStringToSQLTime(rawCtr.DisconnectTimestamp),
    next_contact_id: rawCtr.NextContactId,
    routing_criteria_steps: routingCriteria(rawCtr),
    previous_contact_id: rawCtr.PreviousContactId,
    recording_deletion_reason: safeAccessObject(rawCtr, "Recording.DeletionReason"),
    recording_location: safeAccessObject(rawCtr, "Recording.Location"),
    recording_status: safeAccessObject(rawCtr, "Recording.status"),
    recording_type: safeAccessObject(rawCtr, "Recording.type"),
    scheduled_timestamp: isoStringToSQLTime(rawCtr.ScheduledTimestamp),
    system_endpoint_address: safeAccessObject(rawCtr, "SystemEndpoint.Address"),
    system_endpoint_type: safeAccessObject(rawCtr, "SystemEndpoint.Type"),
    instance_arn: rawCtr.InstanceARN,
  };
  return ctrMapper;
}
/**
 * Function to return the Expression.AndExpression for Status = Joined
 */
export function routingCriteria(rawCtr) {
  try {
    if (Array.isArray(rawCtr.RoutingCriteria)) {
      for (const obj of rawCtr.RoutingCriteria) {
        for (const obj1 of obj.Steps) {
          if (obj1.Status === 'JOINED') {
            return JSON.stringify(obj1.Expression.AndExpression);
          }
        }
      }
    } else {
      logger.info("rawCtr.RoutingCriteria is not an array");
      return null;
    }
  } catch (e) {
    logger.error("error for Status insertion:", e);
    return null;
  }
}
/**
 * Convert a raw CTR object to a SQL query to insert data to tables for ctr attributes.
 * @param {*} rawCtr Parsed CTR object, with AWSAccountId as a direct property.
 * @returns {Object} result: a postgresql prepared statement object that can be reused. https://node-postgres.com/features/queries#prepared-statements
 */
export function ctrAttributesQueryConstructor(rawCtr) {
  /**
   * Translation table of the CTR to schema of ctr_attributes.
   * CTR Attributes are being serialized as JSON.
   * Ref: https://docs.aws.amazon.com/connect/latest/adminguide/ctr-data-model.html
   */
  const ctrMapper = {
    contact_id: rawCtr.ContactId,
    last_update_timestamp: isoStringToSQLTime(rawCtr.LastUpdateTimestamp),
    attributes: JSON.stringify(rawCtr.Attributes),
  };
  return ctrMapper;
}

/**
 * Convert a raw CTR object to a SQL query to insert data to tables for ctr attributes.
 * @param {*} rawCtr Parsed CTR object, with AWSAccountId as a direct property.
 * @param {[String]} patterns Patterns for the attributes to be inserted to the table.
 * @returns {[Object]} results: a postgresql prepared statement object that can be reused. https://node-postgres.com/features/queries#prepared-statements
 */
export function flattenedAttributesQueryConstructor(rawCtr, patterns) {
  let attributes = rawCtr.Attributes;
  let results = [];
  for (const pattern of patterns) {
    let keys = Object.keys(attributes);
    for (const key of keys) {
      if (key.includes(pattern)) {
        // if there's a match, we push the value to results.
        results.push({
          contact_id: rawCtr.ContactId,
          last_update_timestamp: rawCtr.LastUpdateTimestamp,
          key: key,
          value: attributes[key],
        });
        // delete the key from the attributes Next round this key won't be looped again.
        delete attributes[key];
        // // break the loop as this key is already a match so this key won't be pushed twice later by another match.
        // break;
      }
    }
  }
  return results;
}

/**
 * Convert a raw CTR recording to a SQL query to insert data to tables for recordings.
 * @param {*} rawCtr Parsed CTR object, with AWSAccountId as a direct property.
 * @returns {Object} result: an postgresql prepared statement objects that needed to be inserted outside. https://node-postgres.com/features/queries#prepared-statements
 */
export function ctrRecordingsQueryConstructor(rawCtr, element) {
  /**
   * Translation table of the CTR to schema of ctr_attributes.
   * CTR Attributes are being serialized as JSON.
   * Ref: https://docs.aws.amazon.com/connect/latest/adminguide/ctr-data-model.html
   */
  let ctrMapper = {
    contact_id: rawCtr.ContactId,
    last_update_timestamp: isoStringToSQLTime(rawCtr.LastUpdateTimestamp),
    recordings_info_location: element.Location,
    recordings_info_fragment_start_nmbr: element.FragmentStartNumber,
    recordings_info_fragment_stop_nmbr: element.FragmentStopNumber,
    recordings_info_media_stream_type: element.MediaStreamType,
    recordings_info_participant_type: element.ParticipantType,
    recordings_info_start_timestamp:
      isoStringToSQLTime(element.StartTimestamp) || isoStringToSQLTime(safeAccessObject(rawCtr, "Agent.ConnectedToAgentTimestamp")),
    recordings_info_status: element.Status,
    recordings_info_deletion_reason: element.DeletionReason,
    recordings_info_stop_timestamp: isoStringToSQLTime(element.StopTimestamp) || isoStringToSQLTime(rawCtr.DisconnectTimestamp),
    recordings_info_storage_type: element.StorageType,
  };
  return ctrMapper;
}

/**
 * Convert a raw CTR object to a SQL query to insert call quality data
 * @param {*} rawCtr Parsed CTR object, with AWSAccountId as a direct property.
 * @returns {Object[]} result: a postgresql prepared statement object that can be reused. https://node-postgres.com/features/queries#prepared-statements
 */
export function callQualityQueryConstructor(rawCtr) {
  /**
   * Translation table of the CTR to schema of fact_ctr
   * Ref: https://docs.aws.amazon.com/connect/latest/adminguide/ctr-data-model.html
   */
  const callQualityResult = [];
  // The basic info that's stable between events. 
  const ctr_info = {
    contact_id: rawCtr.ContactId,
    last_update_timestamp: isoStringToSQLTime(rawCtr.LastUpdateTimestamp),
    initiation_timestamp: isoStringToSQLTime(rawCtr.InitiationTimestamp),
    enqueue_timestamp: isoStringToSQLTime(safeAccessObject(rawCtr, "Queue.EnqueueTimestamp")),
    dequeue_timestamp: isoStringToSQLTime(safeAccessObject(rawCtr, "Queue.DequeueTimestamp")),
    connected_to_agent_timestamp: isoStringToSQLTime(safeAccessObject(rawCtr, "Agent.ConnectedToAgentTimestamp")),
    connected_to_system_timestamp: isoStringToSQLTime(rawCtr.ConnectedToSystemTimestamp),
    disconnect_timestamp: isoStringToSQLTime(rawCtr.DisconnectTimestamp),
  }
  if (rawCtr.QualityMetrics.Agent && rawCtr.QualityMetrics.Agent.Audio){
    callQualityResult.push({
      ...ctr_info,
      contact_type: "AGENT",
      quality_score: rawCtr.QualityMetrics.Agent.Audio.QualityScore,
      potential_quality_issues: rawCtr.QualityMetrics.Agent.Audio.PotentialQualityIssues.length == 0? null: rawCtr.QualityMetrics.Agent.Audio.PotentialQualityIssues.join(','),
    });
  }
  if (rawCtr.QualityMetrics.Customer && rawCtr.QualityMetrics.Customer.Audio){
    callQualityResult.push({
      ...ctr_info,
      contact_type: "CUSTOMER",
      quality_score: rawCtr.QualityMetrics.Customer.Audio.QualityScore,
      potential_quality_issues: rawCtr.QualityMetrics.Customer.Audio.PotentialQualityIssues.length == 0? null: rawCtr.QualityMetrics.Customer.Audio.PotentialQualityIssues.join(','),
    });
  }
  return callQualityResult;
}

/**
 * Parse CTR data and push it to ODS DB.
 * @param {object[]} data: The parsed object for the s3 object downloaded in the handler
 * @param {String} s3_key_name: The S3 key name for this event.
 * @param {pg.Client} db_client: Database client to push data.
 */
export default async function updateCTR(data, s3_key_name, db_client) {
  logger.info("Attempting to update ODS based on CTR bucket event...");
  let lambdaResult = {
    LambdaSuccess: false,
    message: "",
  };

  /**
   * CTR update in this logic.
   * Handling of CTR is an interesting process. CTR generated in this way will have many source of possibility of duplicates.
   * Only the intended duplicate triggered by update of the CTR after agent hung up needed update.
   * In this case the updated CTR will carry a last updated timestamp. update is only required if this last updated timestamp is newer than the previous one.
   * In any other cases it would be related to duplication-generation sources before this event. (Connect, Kinesis processing Lambda retries, S3 event, this lambda retries.)
   */

  try {
    // connect to db

    await db_client.tryConnect();
    logger.info("Successfully connected DB client.");

    logger.debug(`received data = ${JSON.stringify(data)}`);
    logger.debug(`received data isArray? ${Array.isArray(data)}`);
    logger.debug(`received data.AWSContactTraceRecordFormatVersion=${data.AWSContactTraceRecordFormatVersion}`);

    if (Array.isArray(data) || data.AWSContactTraceRecordFormatVersion !== undefined) {
      // Convert a previous type of CTR where a single file contains a single CTR rather than a list.
      if (data.AWSContactTraceRecordFormatVersion !== undefined) {
        data = [data];
      }

      for (let index = 0; index < data.length; index++) {
        const ctr = data[index];
        logger.info(`Trying to insert ContactId=${ctr.ContactId} into ${CTR_TABLE_NAME}`);

        // Insert the CTR table.
        await insertValue(ctrQueryConstructor(ctr), CTR_TABLE_NAME, db_client);
        // Insert CTR Attributes.
        await insertValue(ctrAttributesQueryConstructor(ctr), CTR_ATTRIBUTES_TABLE_NAME, db_client);
        // Insert flattened attributes
        let pattens = ATTRIBUTES_PATTERN_DEFAULT;
        try {
          pattens = JSON.parse(ATTRIBUTES_PATTERN);
        } catch {
          logger.warn(`ATTRIBUTES_PATTERN Serialization error. envar ATTRIBUTES_PATTERN=${ATTRIBUTES_PATTERN}. 
          Will use default pattens=${JSON.stringify(pattens)}`);
        }
        let flatAtrs = flattenedAttributesQueryConstructor(ctr, pattens);
        if (Array.isArray(flatAtrs) && flatAtrs.length > 0) {
          await Promise.allSettled(flatAtrs.map((attribute) => insertValue(attribute, ATTRIBUTES_FLATTENED_TABLE_NAME, db_client)));
        }

        // insert into recordings table
        if (Array.isArray(ctr.Recordings) && ctr.Recordings.length > 0) {
          await Promise.allSettled(ctr.Recordings.map((item) => insertValue(ctrRecordingsQueryConstructor(ctr, item), CTR_RECORDINGS_TABLE_NAME, db_client)));
        }

        // insert into callQuality table
        if (!!ctr.QualityMetrics) {
          await Promise.allSettled(callQualityQueryConstructor(ctr).map((callQualityEntry) => insertValue(callQualityEntry, CTR_AUDIO_QUALITY_TABLE_NAME, db_client)));
        }

        lambdaResult.LambdaSuccess = true;
        lambdaResult.message = `${[ctr.ContactId]} insert successful.`;
      }
    } else {
      throw new Error(`Unexpected data format: CTR`, { cause: data });
    }

    return lambdaResult;
  } catch (error) {
    logger.error(error.message);
    logger.error(error.stack);
    throw error;
  }
}
