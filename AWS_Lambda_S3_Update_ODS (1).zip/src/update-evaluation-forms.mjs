import logplease from "logplease";
import { v4 as uuidv4 } from "uuid";
import { isoStringToSQLTime, isoStringTimeDiff, safeAccessObject, flattenHierarchy } from "./util/misc.mjs";
// Configure logger
const logger = logplease.create("Logger", { showTimestamp: false, useColors: false });
logplease.setLogLevel(process.env.AWS_LAMBDA_LOGGING_LEVEL);

const EVALUATION_FORMS_TABLE = "fact_evaluation_forms";
const EVALUATION_FORMS_SECTION_TABLE = "fact_evaluation_forms_sections";
const EVALUATION_FORMS_QUESTION_TABLE = "fact_evaluation_forms_questions";
const EVALUATION_FORMS_ANSWER_VALUES_TABLE = "fact_evaluation_forms_answer_values";

async function insertValue(input, table_name, db_client) {
  const keys = Object.keys(input);
  const columnString = keys.join(",");
  const values = keys.map((key) => {
    return input[key] ? input[key] : null;
  });
  let _i = 1;
  const valuesString = values.map(() => "$" + _i++).join(",");
  return await db_client.query({
    text: `INSERT INTO ${table_name} (${columnString})
        VALUES (${valuesString}) ON CONFLICT DO NOTHING;`,
    values: values,
  });
}

export default async function updateEvalForms(data, s3_key_name, db_client) {
  logger.info("Attempting to update ODS based on Evaluation Forms event...");
  let lambdaResult = {
    LambdaSuccess: false,
    message: "",
  };
  let result;

  // data is the Eval forms.
  // Eval form is a single object. This file is untouched by the kinesis.
  // determine if the format is right.
  if (!data.schemaVersion || !data.evaluationId) {
    logger.error(`Unexpected input format for Evaluation forms. The file should have one form only.`);
    logger.error(data);
    throw new Error(`Unexpected input format for Evaluation forms. The file should have one form only.`, { cause: s3_key_name });
  }

  await db_client.tryConnect();
  logger.info("Successfully connected DB client.");

  // if they are right, unpack them here.
  // read the root.
  const evaluation_id = `${data.evaluationId}|${uuidv4()}`;
  const rootMapper = {
    evaluation_id: evaluation_id,
    contact_id: data.metadata.contactId,
    account_id: data.metadata.accountId,
    instance_id: data.metadata.instanceId,
    agent_id: data.metadata.agentId,
    evaluation_definition_title: data.metadata.evaluationDefinitionTitle,
    evaluator: data.metadata.evaluator,
    evaluation_definition_id: data.metadata.evaluationDefinitionId,
    evaluation_definition_version: data.metadata.evaluationDefinitionVersion,
    evaluation_start_timestamp: data.metadata.evaluationStartTimestamp,
    evaluation_submit_timestamp: data.metadata.evaluationSubmitTimestamp,
    score_percentage: safeAccessObject(data, "metadata.score.percentage"),
  };
  result = await insertValue(rootMapper, EVALUATION_FORMS_TABLE, db_client);
  
  logger.info(`${result.command} SUCCESS. table=${EVALUATION_FORMS_TABLE}, rowCount=${result.rowCount===null?0:result.rowCount}`)



  // read all the sections.
  if (Array.isArray(data.sections)) {
    let results = [];
    for await (const section of data.sections) {
      const sectionMapper = {
        section_ref_id: section.sectionRefId,
        evaluation_id: evaluation_id,
        section_title: section.sectionTitle,
        parent_section_ref_id: section.parentSectionRefId, // maybe undefined but expected.
        score_percentage: safeAccessObject(section, "score.percentage"), // may need to safe extract
      };
      results.push(await insertValue(sectionMapper, EVALUATION_FORMS_SECTION_TABLE, db_client));
    }
    logger.info(`INSERT SUCCESS. table=${EVALUATION_FORMS_SECTION_TABLE}, rowCount=${results.reduce((total,curr)=>total+curr.rowCount,0)}`);
  } else {
    // handle sections not an array.
    logger.debug(`Type of data.sections=${typeof data.sections}`);
    throw Error(`Unexpected type of data.sections. Expect Array, got ${typeof data.sections}.`);
  }

  // read all the questions.
  if (Array.isArray(data.questions)) {
    let questions_results = [];
    for await (const question of data.questions) {
      const questionMapper = {
        evaluation_id: evaluation_id,
        question_ref_id: question.questionRefId,
        section_ref_id: question.sectionRefId,
        question_type: question.questionType,
        question_text: question.questionText,
        answer_notes: question.answer.notes,
        answer_metadata_not_applicable: safeAccessObject(question, "answer.metadata.notApplicable"), // may need to safe extract
        answer_metadata_automation_system_suggested_value: safeAccessObject(question,"answer.metadata.automation.systemSuggestedValue"), // may need to safe extract
        answer_metadata_automation_status: safeAccessObject(question,"answer.metadata.automation.status"),
        score_percentage: safeAccessObject(question,"score.percentage"),
      };
      questions_results.push(await insertValue(questionMapper, EVALUATION_FORMS_QUESTION_TABLE, db_client));
      // read all the answer values.
      if (Array.isArray(question.answer.values) && question.answer.values.length > 0) {
        let values_results =[];
        for await (const value of question.answer.values) {
          const valueMapper = {
            evaluation_id: evaluation_id,
            question_ref_id: question.questionRefId,
            section_ref_id: question.sectionRefId,
            value_ref_id: value.valueRefId,
            value_text: value.valueText,
            selected: value.selected,
          };
          values_results.push(await insertValue(valueMapper, EVALUATION_FORMS_ANSWER_VALUES_TABLE, db_client));
        }
        logger.info(`INSERT SUCCESS. table=${EVALUATION_FORMS_ANSWER_VALUES_TABLE}, rowCount=${values_results.reduce((total,curr)=>total+curr.rowCount,0)}`);
      } else {
        logger.info(`Received empty answer values field.`);
      }
    }
    logger.info(`INSERT SUCCESS. table=${EVALUATION_FORMS_QUESTION_TABLE}, rowCount=${questions_results.reduce((total,curr)=>total+curr.rowCount,0)}`);
  } else {
    // handle questions not an array.
    logger.debug(`Type of data.questions=${typeof data.questions}`);
    throw Error(`Unexpected type of data.questions. Expect Array, got ${typeof data.questions}.`);
  }
  lambdaResult.LambdaSuccess = true;
  lambdaResult.message = `${evaluation_id} inserted successfully`;
  return lambdaResult;
}
