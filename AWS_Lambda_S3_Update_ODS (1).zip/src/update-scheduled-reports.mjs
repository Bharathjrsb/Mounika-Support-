import logplease from "logplease";
import { parse } from "csv-parse";

// Configure logger
const logger = logplease.create("Logger", {
  showTimestamp: false,
  useColors: false,
});
logplease.setLogLevel(process.env.AWS_LAMBDA_LOGGING_LEVEL);

const ODS_AGG_AGENT_QUEUE = "ods_oob_agg_agent_queue";
const ODS_AGG_QUEUE = "ods_oob_agg_queue";
const ODS_AGG_AGENT_HIER1 = "ods_oob_agg_agent_hier1";
const ODS_AGG_ROUTING_PROFILE = "ods_oob_agg_routing_profile";
const ODS_AGG_AGENT_DAILY_SUMMARY = "ods_oob_agent_daily_summary";
const ODS_CSV_PROCESSING_RECORD = "ods_oob_csv_processing_record";

const TABLE_TRANSLATION = {
  ODS_AgentHier1: ODS_AGG_AGENT_HIER1,
  ODS_AgentQueue: ODS_AGG_AGENT_QUEUE,
  ODS_Queue: ODS_AGG_QUEUE,
  ODS_RoutingProfile: ODS_AGG_ROUTING_PROFILE,
  ODS_Agent_Daily_Summary: ODS_AGG_AGENT_DAILY_SUMMARY
};

const TODO = null;

let agentQueueInput;

/**
 * Implementation of the conversion from CSV header to table schema.
 * @param {String} input CSV Headers
 * @returns sql table schema of the respective CSV header.
 */
export function getSchemaColumnName(input) {
  /**
    Comments on CSV headers and Schema.
    ODS schema for scheduled reports should be defined by the exported metrics to keep consistency.
    the conversion should be defined clearly so when new headers were added it can be added following the rule.
    Currently the logic is designed as the following steps:

    1. Direct convert:
    Following 2 csv headers will do a direct convert to their counterparts. 
        StartInterval -> start_interval
        EndInterval -> end_interval
    Ideally, we don't add new headers to this step of processing in the future.
    2. Convert all letters to lower case. 
    3. Replace all special characters that's not alphanumerical or a space (" "), to a space.
    4. Replace the following words to shorten the length: 
        average -> avg
        customer -> cust
        maximum -> max
        "after contact work" -> acw
    5. Trim all the fields, then replace all the single or multiple white space characters to ONE underscore ("_")
 */
  const abbreviations = {
    average: "avg",
    customer: "cust",
    maximum: "max",
    "after contact work": "acw",
  };

  switch (input) {
    // Start step 1 requirement
    case "StartInterval":
      return "start_interval";
    case "EndInterval":
      return "end_interval";
    // End step 1 requirement
    default:
      // Start step 2 requirement
      input = input.toLowerCase();
      // End step 2 requirement

      // Start step 3 requirement
      input = input.replaceAll(/[^0-9a-z ]{1}/gi, " ");
      // End step 3 requirement

      // Start step 4 requirement
      for (const conversions of Object.entries(abbreviations)) {
        input = input.replaceAll(conversions[0], conversions[1]);
      }
      // End step 4 requirement

      // Start step 5 requirement
      input = input.trim();
      input = input.replaceAll(/\s{1,}/gi, "_");
      // End step 5 requirement
      return input;
  }
}

/**
 * Get all the columns for a given table, retrieved from information schema.
 * @param {String} tableName
 * @param {Client} db_client Database Client object
 * @returns Rows containing the columns currently existing in database.
 */
async function getCurrentTableSchema(tableName, db_client) {
  let result = await db_client.query({
    text: `SELECT column_name FROM information_schema.columns WHERE table_name = $1;`,
    values: [tableName],
    rowMode: "array",
  });
  return result.rows.flat();
}

/**
 *
 * @param {String} tableName Table name to be altered
 * @param {String} columnName Column name to be added to the table
 * @param {Client} db_client Database Client object
 * @returns
 */
// async function alterTableAddColumn(tableName, columnName, db_client) {
//   let result = await db_client.query({
//     text: `ALTER TABLE $1 ADD COLUMN $2 integer;`,
//     values: [tableName, columnName],
//   });
//   return result;
// }

async function csvInsertBuilder(tableName, columnString, valuesString, values, db_client) {
  const query = {
    text: `INSERT INTO ${tableName} (${columnString})
        VALUES (${valuesString});`,
    values: values,
  };
  try {
    return await db_client.query(query);
  } catch (error) {
    throw new Error(`Insert failure: Schedule Reports.`, { cause: { message: error.message, stack: error.stack, ...error, text: query.text } });
  }
}

/**
 * Parse Agent Event data and push it to ODS DB.
 * @param {ReadableStream} inputStream: The parsed object for the s3 object downloaded in the handler
 * @param {String} s3KeyName: The s3 key name of the file.
 * @param {pg.Client} db_client: Database client to push data.
 */
export default async function updateScheduledReportEvent(inputStream, s3KeyName, db_client) {
  logger.info("Attempting to update ODS based on Agent Event bucket event...");
  let lambdaResult = {
    LambdaSuccess: false,
    message: "",
  };
  let workingTable = [];

  Object.keys(TABLE_TRANSLATION).forEach((name) => {
    if (s3KeyName.search(name) >= 0) {
      workingTable.push(TABLE_TRANSLATION[name]);
    }
  });
  if (workingTable.length === 0) {
    // Matched zero patterns, this entry should be ignored.
    logger.info(`Ignoring ${s3KeyName}: Not matching processing patterns.`);
    lambdaResult.LambdaSuccess = true;
    lambdaResult.message = `Ignoring ${s3KeyName}: Not matching processing patterns.`;
    return lambdaResult;
  } else if (workingTable.length > 1) {
    throw new Error(`Unexpected input: Scheduled Report table matching`, { cause: s3KeyName });
  }

  workingTable = workingTable[0];
  let schemaRebuild = false;

  try {
    await db_client.tryConnect();
    logger.info("Successfully connected DB client.");
    try {
      await db_client.query({
        text: `INSERT INTO ${ODS_CSV_PROCESSING_RECORD} VALUES ($1, $2);`,
        values: [s3KeyName, "PROCESSING"],
      });
    } catch (error) {
      logger.info(`s3File=${s3KeyName} Already present in table ${ODS_CSV_PROCESSING_RECORD}, skipping`);
      lambdaResult.LambdaSuccess = false;
      lambdaResult.message = { key_name: s3KeyName, error: `s3File=${s3KeyName} Already present in table ${ODS_CSV_PROCESSING_RECORD}, skipping` };
      return lambdaResult;
    }
    const parser = inputStream.pipe(parse({ trim: true, info: true }));
    let missingSchema = [];
    let csvHeader = [];
    let columnString;
    let valuesString;
    let non_empty_lines = 0;
    let inserted = 0;
    let begin = false;

    for await (const record of parser) {
      if (record.info.lines === 1) {
        // Processing the header.
        let currentSchema = new Set(await getCurrentTableSchema(workingTable, db_client));
        csvHeader = record.record.map((item) => getSchemaColumnName(item));
        // Determine if we are missing schema.
        csvHeader.forEach((item) => {
          if (!currentSchema.has(item)) {
            missingSchema.push(item);
          }
        });
        if (missingSchema.length > 0) {
          schemaRebuild = true;
          logger.info(`Missing Columns in table ${workingTable}. Current Schema length=${currentSchema.size} Missing ${missingSchema.length} column(s).`);
          await db_client.query({
            text: `INSERT INTO ${ODS_CSV_PROCESSING_RECORD} (s3_key_name,processing_status) VALUES ($1, $2)
            ON CONFLICT (s3_key_name) DO UPDATE SET processing_status = EXCLUDED.processing_status;`,
            values: [s3KeyName, "FAILED"],
          });
          throw new Error(`Missing Column: Table=${workingTable}, Missing columns=${missingSchema}`, { cause: s3KeyName });
        } else {
          logger.info(`CSV has same headers as table schema`);
        }
        // columns
        columnString = csvHeader.join(",");
        // Populate the $1, $2 ..
        let _i = 1;
        valuesString = csvHeader.map(() => "$" + _i++).join(",");
      } else {
        // processing data entries.
        let line = record.record.map((item) => {
          if (item === "") {
            // empty fields
            return null;
          } else if (!isNaN(Number(item))) {
            return Number(item);
          } else {
            if (item.search("%") > -1) {
              // It's a percentage.
              return Number(item.replace("%", ""));
            }
            // it's a string/timestamp, can be inserted as-is.
            return item;
          }
        });

        if (!begin) {
          await db_client.query("BEGIN;");
          begin = true;
        }
        let query = await csvInsertBuilder(workingTable, columnString, valuesString, line, db_client);
        inserted += query.rowCount;
        non_empty_lines += 1;
      }
    }
    // start to commit the records.
    if (begin) {
      try {
        let lockCheck = await db_client.query({
          text: `UPDATE ${ODS_CSV_PROCESSING_RECORD} SET processing_status = $1 WHERE s3_key_name = $2 AND processing_status = $3;`,
          values: ["SUCCEEDED", s3KeyName, "PROCESSING"],
        });
        if (lockCheck.rowCount !== 1) {
          // Update failure, rollback.
          throw new Error(`Update Processing records failure, trying updating ${s3KeyName} to SUCCEEDED but current status is not PROCESSING.`);
        }
        await db_client.query("COMMIT;");
      } catch (error) {
        await db_client.query("ROLLBACK;");
        await db_client.query({
          text: `INSERT INTO ${ODS_CSV_PROCESSING_RECORD} (s3_key_name,processing_status) VALUES ($1, $2)
          ON CONFLICT (s3_key_name) DO UPDATE SET processing_status = EXCLUDED.processing_status;`,
          values: [s3KeyName, "FAILED"],
        });
        throw error;
      }
    } else {
      // reached here without begin==true - we got an empty file.
      await db_client.query({
        text: `INSERT INTO ${ODS_CSV_PROCESSING_RECORD} (s3_key_name,processing_status) VALUES ($1, $2)
        ON CONFLICT (s3_key_name) DO UPDATE SET processing_status = EXCLUDED.processing_status;`,
        values: [s3KeyName, "SUCCEEDED"],
      });
    }

    lambdaResult.LambdaSuccess = true;
    lambdaResult.message = { key_name: s3KeyName, inserted: inserted, non_empty_lines: non_empty_lines, ...parser.info };
    return lambdaResult;
  } catch (error) {
    logger.error(error);
    logger.error(error.message);
    logger.error(error.stack);
    throw error;
  }
}
