import pg from "pg";
const { Client } = pg;
import logplease from "logplease";

import { SecretsManager } from "@aws-sdk/client-secrets-manager";

// Configure logger
const logger = logplease.create("Logger", { showTimestamp: false, useColors: false });
logplease.setLogLevel(process.env.AWS_LAMBDA_LOGGING_LEVEL);

const DB_SECRET_ARN = process.env.DB_SECRET_ARN;
const DB_HOST = process.env.DB_HOST;
const DB_PORT = process.env.DB_PORT;
const DB_NAME = process.env.DB_NAME;

class MyPGClient extends Client {
  async tryConnect() {
    if (this._connecting || this._connected) {
      logger.info("DB already connected.");
      return;
    } else {
      return this.connect();
    }
  }
}

// Configure the Postgres DB client.
export default async () => {
  // Get the login creds from secrets manager.
  const secrets_client = new SecretsManager();
  const secret_res = await secrets_client.getSecretValue({
    SecretId: DB_SECRET_ARN,
  });
  logger.info("Found DB secret.");
  const db_secret = JSON.parse(secret_res.SecretString);

  // Connect the client.
  // Added 3 seconds of timeout to db connection to fail early than hitting lambda timeout
  const db_client_config = {
    host: DB_HOST,
    port: DB_PORT,
    database: DB_NAME.toLowerCase(),
    connectionTimeoutMillis: 3000,
    query_timeout: 3000,
    user: db_secret.username,
  };
  logger.debug("DB client config: " + JSON.stringify(db_client_config));
  const db_client = new MyPGClient({
    ...db_client_config,
    password: db_secret.password,
  });

  return db_client;
};
