import { getSchemaColumnName } from "../update-scheduled-reports.mjs";
import { argv } from "node:process";
import { open } from "node:fs/promises";

/**
 * Following columns is a list of historical metric appearing in the current oob ods schema.
 * The type is matching with the current schema.
 */

const approved_oob_columns = {
  start_interval: "timestamp with time zone",
  end_interval: "timestamp with time zone",
  vp: "character varying",
  agent_answer_rate: "numeric",
  abandonment_rate: "numeric",
  agent_api_connecting_time: "integer",
  agent_callback_connecting_time: "integer",
  agent_idle_time: "integer",
  agent_incoming_connecting_time: "integer",
  contacts_missed: "integer",
  agent_on_contact_time: "integer",
  agent_outbound_connecting_time: "integer",
  avg_agent_api_connecting_time: "integer",
  avg_agent_callback_connecting_time: "integer",
  avg_agent_incoming_connecting_time: "integer",
  avg_agent_outbound_connecting_time: "integer",
  error_status_time: "integer",
  nonproductive_time: "integer",
  occupancy: "numeric",
  online_time: "integer",
  adherence: "numeric",
  adherent_time: "integer",
  non_adherent_time: "integer",
  scheduled_time: "integer",
  null_time: "integer",
  wrap_up_time: "integer",
  training_new_hire_time: "integer",
  training_corporate_time: "integer",
  training_continuing_education_time: "integer",
  personal_time: "integer",
  meeting_time: "integer",
  lunch_time: "integer",
  coaching_time: "integer",
  break_time: "integer",
  busy_time: "integer",
  not_available_time: "integer",
  outbound_call_time: "integer",
  contacts_abandoned_in_20_seconds: "integer",
  contacts_abandoned_in_60_seconds: "integer",
  contacts_abandoned_in_300_seconds: "integer",
  contacts_answered_in_20_seconds: "integer",
  contacts_answered_in_60_seconds: "integer",
  contacts_answered_in_300_seconds: "integer",
  service_level_20_seconds: "numeric",
  service_level_60_seconds: "numeric",
  service_level_300_seconds: "numeric",
  acw_time: "integer",
  agent_interaction_and_hold_time: "integer",
  agent_interaction_time: "integer",
  api_contacts: "integer",
  api_contacts_handled: "integer",
  avg_acw_time: "integer",
  avg_agent_interaction_and_cust_hold_time: "integer",
  avg_agent_interaction_time: "integer",
  avg_cust_hold_time: "integer",
  avg_handle_time: "integer",
  avg_outbound_acw_time: "integer",
  avg_outbound_agent_interaction_time: "integer",
  avg_queue_abandon_time: "integer",
  avg_queue_answer_time: "integer",
  callback_contacts: "integer",
  callback_contacts_handled: "integer",
  contact_flow_time: "integer",
  contact_handle_time: "integer",
  contacts_abandoned: "integer",
  contacts_agent_hung_up_first: "integer",
  contacts_handled: "integer",
  contacts_handled_incoming: "integer",
  contacts_handled_outbound: "integer",
  contacts_hold_agent_disconnect: "integer",
  contacts_hold_cust_disconnect: "integer",
  contacts_hold_disconnect: "integer",
  contacts_incoming: "integer",
  contacts_put_on_hold: "integer",
  contacts_queued: "integer",
  contacts_transferred_in: "integer",
  contacts_transferred_in_from_queue: "integer",
  contacts_transferred_out: "integer",
  contacts_transferred_out_external: "integer",
  contacts_transferred_out_from_queue: "integer",
  contacts_transferred_out_internal: "integer",
  cust_hold_time: "integer",
  max_queued_time: "integer",
  contacts_transferred_in_by_agent: "integer",
  contacts_transferred_out_by_agent: "integer",
  create_dt: "timestamp with time zone,  -- REMOVE ME IF NOT APPLICABLE",
  modify_dt: "timestamp with time zone,  -- REMOVE ME IF NOT APPLICABLE",
  agent: "character varying",
  queue: "character varying",
  agent_name: "character varying",
  agent_last_name: "character varying",
  agent_first_name: "character varying",
  routing_profile: "character varying",
  serv_desk_tnh_time: "integer",
};

function getApprovedOobColumn(input) {
  if (!approved_oob_columns[getSchemaColumnName(input)]) {
    return `>>>UNKNOWN TYPE PLEASE DECIDE MANUALLY<<<`;
  }
  return approved_oob_columns[getSchemaColumnName(input)];
}

try {
  if (argv.length < 4) {
    throw new Error("Too few inputs provided. Please refer to the usage.");
  }
  if (!argv[3]) {
    throw new Error("Please provide me a proposed table name.");
  }
  let fp = await open(argv[2]);
  let tableName = getSchemaColumnName(argv[3]);
  let firstline;
  for await (const line of fp.readLines()) {
    firstline = line;
    fp.close();
    break;
  }
  let items = firstline.split(",").concat(["create_dt", "modify_dt"]);
  items = items.map((i) => `${getSchemaColumnName(i)} ${getApprovedOobColumn(i)}`);
  let command = `-- This command creates a table named ${tableName}. Please verify the commands before executing!
-- This command also creates the triggers. Please verify if this table needs them. 
DROP TABLE IF EXISTS ${tableName};

CREATE TABLE ${tableName} (
  ${items.join(",\n  ")}
);
CREATE OR REPLACE TRIGGER ${tableName}_create_dt
  BEFORE INSERT ON ${tableName} FOR EACH ROW EXECUTE FUNCTION update_create_timestamp();
CREATE OR REPLACE TRIGGER ${tableName}_modify_dt
  BEFORE INSERT ON OR UPDATE ON ${tableName} FOR EACH ROW EXECUTE FUNCTION update_modify_timestamp();`;
  console.log(command);
} catch (error) {
  console.log(error.message);
  console.log(error.stack);
  console.log("USAGE: node create-header-with-csv.mjs [input_file_name] [new_table_name]");
  // console.log("OPTIONS:\n  -c: add create_dt trigger.\n  -m: add modify_dt trigger.");
}
