import logplease from "logplease";
// Configure logger
const logger = logplease.create("Logger", { showTimestamp: false, useColors: false });
logplease.setLogLevel(process.env.AWS_LAMBDA_LOGGING_LEVEL);

/**
 *
 * @param {Object} input The input to be inserted to a database. The input must be a flat object with column name as key and values in the values.
 * @param {String} table_name Table name as a string
 * @param {Object} db_client The db client object
 * @returns The awaited promise in insertion query outlined in https://node-postgres.com/apis/result.
 * Errors will be unhandled
 */
export async function insertValue(input, table_name, db_client) {
  const keys = Object.keys(input);
  const columnString = keys.join(",");
  const values = keys.map((key) => {
    return input[key] ? input[key] : null;
  });
  let _i = 1;
  const valuesString = values.map(() => "$" + _i++).join(",");
  if (process.env.AWS_LAMBDA_LOGGING_LEVEL === "DEBUG") {
    logger.debug(`insert tableName=${table_name}`);
    logger.debug(`inserting:`, input);
  }
  return db_client.query({
    text: `INSERT INTO ${table_name} (${columnString})
        VALUES (${valuesString}) ON CONFLICT DO NOTHING;`,
    values: values,
  });
}

/**
 * This function is currently under construction, related to US 8100679
 * @param {Object} input The input object for insertion
 * @param {Object} input.query The query to be inserted to database. It must be a flat object with column name as key and values in the values.
 * @param {String} input.table_name Table name as a string.
 * @param {"update"|"ignore"|"error"} input.on_conflict The ON CONFLICT action of the insert. 
    Update will do an update action to replace the old value (UPSERT), 
    Ignore will not update the value and not return the error. 
    Error will return an error if the entry is already there.
    Default will be error.
 * @param {Object} db_client The db client object
 * @returns The awaited promise in insertion query outlined in https://node-postgres.com/apis/result.
 */
// export async function insertValueV2(input, db_client) {
//   const query = input.query;
//   const table_name = input.table_name;

//   let on_conflict_action;
//   switch (input.on_conflict.toLowerCase()) {
//     case "update":

//     case "ignore":
//     case "error":
      
//       break;
      
      
//     default:
//       break;
//   }

//   const keys = Object.keys(query);
//   const columnString = keys.join(",");
//   const values = keys.map((key) => {
//     return query[key] ? query[key] : null;
//   });
//   let _i = 1;
//   const valuesString = values.map(() => "$" + _i++).join(",");
//   if (process.env.AWS_LAMBDA_LOGGING_LEVEL === "DEBUG") {
//     logger.debug(`insert tableName=${table_name}`);
//     logger.debug(`inserting:`, query);
//   }
//   return db_client.query({
//     text: `INSERT INTO ${table_name} (${columnString})
//         VALUES (${valuesString}) ON CONFLICT DO NOTHING;`,
//     values: values,
//   });
// }

/**
 * Given an ISO8601 Timestamp with timezone, convert it to a SQL query text.
 * @param {*} input: json timestamp from CTR
 * @param {date|time|timestamp} option: Case insensitive enum of output type:
 *      date: output the SQL query to insert a date in YYYY-MM-DD format.
 *      time: output the SQL query to insert a time in UTC in HH:mm:ss.SSSZ
 *      timestamp. output the SQU query to insert a timestamp in UTC in ISO8601
 *      Default: output a timestamp SQL query.
 * @returns {String} SQL query text.
 */
export function isoStringToSQLTime(input, option) {
  let ts = new Date(input);
  if (!input || isNaN(ts)) {
    // Either we have a falsy input, or the string passed cannot be passed as a correct timestamp.
    return null;
  } else {
    let [date, time] = ts.toISOString().split("T");
    !option ? (option = "timestamp") : (option = option.toLowerCase());
    switch (option) {
      case "date":
        // YYYY-MM-DD.
        return `${date}`;
      case "time":
        //HH:mm:ss.SSSZ
        return `${time}`;
      case "timestamp":
      default:
        return `${input}`;
    }
  }
}

/**
 * given 2 ISO string timestamps, calculate the time difference in seconds.
 * @param {String} time1 ISO String timestamp 1
 * @param {String} time2 ISO String timestamp 2
 * @returns {int} absolute time difference in seconds.
 */
export function isoStringTimeDiff(time1, time2) {
  try {
    let ts1 = new Date(time1);
    let ts2 = new Date(time2);
    return Math.abs(Math.round((ts1 - ts2) / 1000));
  } catch (error) {
    logger.error(`isoStringTimeDiff cannot parse ${time1} and/or ${time2}, returning 0.`);
    return 0;
  }
}

/**
 * Safely access the object's attribute without raising exceptions. Useful when accessing multi-level attributes.
 * for example, when trying to access `CTR.Agent.RoutingProfile.Name`, passing the following:
 * ```
 * safeAccessObject(CTR, "Agent.RoutingProfile.Name");
 * ```
 * Will safely access the end value for you without raising exceptions.
 * Note that this function does not handle array.
 * @param {*} input the object trying to access
 * @param {*} attr the attributes in dot notation.
 * @returns {any|undefined|null} returns undefined when the value is undefined, returns null when one mid-level is undefined.
 */
export function safeAccessObject(input, attr) {
  const attrList = attr.split(".");
  let position = input;
  let i = 0;
  try {
    for (i = 0; i < attrList.length; i++) {
      // will raise TypeError when we hit an undefined & trying to access property.
      position = position[attrList[i]];
      if (i == attrList.length - 1) {
        return position;
      }
    }
  } catch (err) {
    logger.info(`input.${attrList[i - 1]}.${attrList[i]} does not exist. Returning null for ODS insert.`);
    return null;
  }
}

/**
 * This function is used to flatten the Hierarchy Groups passed in from the Agent event streams and
 * CTR data. It unpacks the Hierarchy groups by it's name and separated them with a pointy bracket, from
 * Level1 to Level5.
 * @param {Object} hierarchyGroups AgentHierarchyGroups Object described in
 * https://docs.aws.amazon.com/connect/latest/adminguide/ctr-data-model.html
 * and https://docs.aws.amazon.com/connect/latest/adminguide/agent-event-stream-model.html
 * @returns {String} Flattened Hierarchy with their name separated with '>'
 */
export function flattenHierarchy(hierarchyGroups) {
  if (!hierarchyGroups) {
    return null;
  }
  // AWS's object naming convention: Consistently inconsistent.
  const hgArray = [
    safeAccessObject(hierarchyGroups, "Level1.GroupName") || safeAccessObject(hierarchyGroups, "Level1.Name"),
    safeAccessObject(hierarchyGroups, "Level2.GroupName") || safeAccessObject(hierarchyGroups, "Level2.Name"),
    safeAccessObject(hierarchyGroups, "Level3.GroupName") || safeAccessObject(hierarchyGroups, "Level3.Name"),
    safeAccessObject(hierarchyGroups, "Level4.GroupName") || safeAccessObject(hierarchyGroups, "Level4.Name"),
    safeAccessObject(hierarchyGroups, "Level5.GroupName") || safeAccessObject(hierarchyGroups, "Level5.Name"),
  ];
  return hgArray.join(">");
}

/**
 * Convert camel case string to underscore representation which obviously postgresql likes.
 * @param {String} input
 */
export function camelCaseToUnderscores(input) {
  input = input.replaceAll(/[A-Z]{1}/g, (i) => {
    return "_" + i.toLowerCase();
  });
  input = input.replaceAll("__", "_");
  if (input.startsWith("_")) {
    input = input.replace("_", "");
  }
  return input;
}
