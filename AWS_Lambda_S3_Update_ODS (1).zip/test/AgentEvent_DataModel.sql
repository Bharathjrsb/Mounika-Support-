/*
 Schema based on the documentation 
 https://docs.aws.amazon.com/connect/latest/adminguide/agent-event-stream-model.html
 Inspired with experience learned through CTR implementations
 */
/*
 Table considerations. 
 End user need a table of agent states, using this table they will be able to look back 
 what had happened to a specific agent between time_x and time_y. 
 Proposing a single fact table for agent snapshots only instead of the agent events. This table 
 should have agentname and status readily available in there. User can use simple query like the following:
 
 SELECT * 
 FROM fact_agent_event_snapshots 
 WHERE Username=JoSmith 
 AND StartTimeStamp BETWEEN 19700101 AND 19700102
 ORDER BY Eventtimestamp DESC
 GROUP BY ROUTABLE;
 
 ... to get specific agent's activity audit between specific dates. 
 
 Collection process pseudo-code
 
 let event;
 if (event is heartbeat){
 ignore event (Or we can build a table to maintain this temporary relationship)
 }
 else{
 Insert only currentagentSnapshots, as they has correct timestamps
 }
 End pseudo-code
 
 
 */
DROP TABLE IF EXISTS fact_agent_event_snapshots;

CREATE TABLE fact_agent_event_snapshots (
    username varchar,
    -- (CurrentagentSnapshot.Configuration.Username),  foreign key to dim_user
    agent_arn varchar,
    -- primary Key
    snapshot_timestamp timestamp,
    -- primary Key2, either the StateStarttimestamp of a Contact, or Eventtimestamp, if there's no contact for this snapshot. 
    agent_status_arn varchar,
    agent_status_name varchar,
    agent_status_type varchar,
    agent_status_start_timestamp timestamp,
    -- (Currentagent_Snapshot.agent_Status.Starttimestamp)
    configuration_agent_hierarchy_groups varchar,
    -- L5->L1 string print as what bill wanted, a snapshot of the hierarchy
    configuration_auto_accept boolean,
    configuration_first_name varchar,
    -- do we need these if user table maintains it. ? 
    configuration_language_code varchar,
    configuration_last_name varchar,
    -- do we need these if user table maintains it. ? 
    configuration_sip_address varchar,
    configuration_routing_profile_arn varchar,
    configuration_routing_profile_name varchar,
    configuration_routing_profile_concurrency varchar,
    -- TODO: unpack concurrency list 
    configuration_routing_profile_default_outbound_queue_name varchar,
    configuration_routing_profile_default_outbound_queue_channels varchar,
    -- TODO: Unpack Channels. 
    configuration_routing_profile_inbound_queues varchar,
    -- TODO: Unpack Inboundqueues.
    contact_channel varchar,
    contact_connected_to_agent_timestamp timestamp,
    contact_contact_id varchar,
    contact_initial_contact_id varchar,
    contact_initiation_method varchar,
    contact_queue_name varchar,
    contact_queue_timestamp timestamp,
    contact_state varchar,
    contact_state_start_timestamp timestamp,
    agent_event_version varchar,
    create_dt timestamp,
    modify_dt timestamp,
    PRIMARY KEY (agent_arn, snapshot_timestamp)
);

ALTER TABLE
    fact_agent_event_snapshots
ADD
    FOREIGN KEY (agent_arn) REFERENCES dim_user (arn);