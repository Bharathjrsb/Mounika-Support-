
-- Begin table configuration.
-- DROP ROLE IF EXISTS "lambda";

DROP TABLE IF EXISTS "fact_ctr";
CREATE TABLE "fact_ctr" (
  "contact_id" varchar,
  "LastUpdateTimestamp" timestamp,
  "AWSAccountId" varchar,
  "AWSContactTraceRecordFormatVersion" varchar,
  "date_key" int,
  "time_key" int,
  "queue_name" varchar,
  "routingprofile_name" varchar,
  "channel_name" varchar,
  "initiation_method" varchar,
  "mediastream_type" varchar,
  "disconnect_reason" varchar,
  "username" varchar,
  "agenthierarchy_id" varchar,
  "AfterContactWorkDuration" int,
  "AgentConnectionAttempts" int,
  "AfterContactWorkEndTimestamp" timestamp,
  "AfterContactWorkStartTimestamp" timestamp,
  "agent_arn" varchar,
  "LongestHoldDuration" int,
  "AgentInteractionDuration" int,
  "CustomerHoldDuration" int,
  "InitialContactId" varchar,
  "InitiationTimestamp" timestamp,
  "RelatedContactId" varchar,
  "TransferCompletedTimestamp" timestamp,
  "TransferredToEndpoint" varchar,
  "ExternalThirdPartyInteractionDuration" timestamp,
  "contact_handle_duration" int,
  "callback_contacts_count" int,
  "contact_flow_time" int,
  "contacts_abandoned_count" int,
  "contacts_abandoned_queue_time" int,
  "contacts_answered_queue_time" int,
  "contacts_disconnectedbyagent_while_on_hold" int,
  "contacts_disconnectedbycustomer_while_on_hold" int,
  "contact_on_hold_count" int,
  "contacts_queued_count" int,
  "contacts_transferred_out_count" int,
  "contacts_transferred_out_byagent_count" int,
  "queue_duration" int,
  "customer_endpoint_Address" varchar,
  "customer_endpoint_type" varchar,
  "enqueue_timestamp" timestamp,
  "dequeue_timestamp" timestamp,
  "connectedtoagent_timestamp" timestamp,
  "connectedtosystem_timestamp" timestamp,
  "disconnect_timestamp" timestamp,
  "disconnect_date_key" int,
  "disconnect_time_key" int,
  "NextContactID" varchar,
  "PreviousContactId" varchar,
  "recording_DeletionReason" varchar,
  "recording_Location" varchar,
  "recording_status" varchar,
  "recording_type" varchar,
  "ScheduledTimestamp" timestamp,
  "system_endpoint_address" varchar,
  "system_endpoint_type" varchar,
  "InstanceARN" varchar,
  "create_dt" timestamp,
  "modify_dt" timestamp,
  PRIMARY KEY ("contact_id", "LastUpdateTimestamp")
);

DROP TABLE IF EXISTS "dim_queue";
CREATE TABLE "dim_queue" (
  "queue_name" varchar PRIMARY KEY,
  "arn" varchar,
  "description" varchar,
  "id" varchar,
  "queue_type" varchar,
  "status" varchar,
  "create_dt" timestamp,
  "modify_dt" timestamp
);

DROP TABLE IF EXISTS "ctr_attributes";
CREATE TABLE "ctr_attributes" (
  "contact_id" varchar,
  "LastUpdateTimestamp" timestamp,
  "Attributes" varchar,
  "create_dt" timestamp,
  "modify_dt" timestamp,
  PRIMARY KEY ("contact_id", "LastUpdateTimestamp")
);

DROP TABLE IF EXISTS "ctr_recordings";
CREATE TABLE "ctr_recordings" (
  "contact_id" varchar,
  "LastUpdateTimestamp" timestamp,
  "recordingsInfo_Location" varchar,
  "recordingsInfo_FragmentStartNumber" varchar,
  "recordingsInfo_FragmentStopNumber" varchar,
  "recordingsInfo_MediaStreamType" varchar,
  "recordingsInfo_ParticipantType" varchar,
  "recordingsInfo_StartTimestamp" timestamp,
  "recordingsInfo_Status" varchar,
  "recordingsInfo_DeletionReason" varchar,
  "recordingsInfo_StopTimestamp" timestamp,
  "recordingsInfo_StorageType" varchar,
  "create_dt" timestamp,
  "modify_dt" timestamp,
  PRIMARY KEY ("contact_id", "LastUpdateTimestamp","recordingsInfo_StopTimestamp")
);

DROP TABLE IF EXISTS "dim_routingprofile";
CREATE TABLE "dim_routingprofile" (
  "routingprofile_name" varchar PRIMARY KEY,
  "arn" varchar,
  "description" varchar,
  "create_dt" timestamp,
  "modify_dt" timestamp
);

DROP TABLE IF EXISTS "dim_initiationmethod";
CREATE TABLE "dim_initiationmethod" (
  "initiation_method" varchar PRIMARY KEY,
  "create_dt" timestamp,
  "modify_dt" timestamp
);

DROP TABLE IF EXISTS "dim_channel";
CREATE TABLE "dim_channel" (
  "channel_name" varchar PRIMARY KEY,
  "create_dt" timestamp,
  "modify_dt" timestamp
);

DROP TABLE IF EXISTS "dim_mediastreamtype";
CREATE TABLE "dim_mediastreamtype" (
  "mediastream_type" varchar PRIMARY KEY,
  "create_dt" timestamp,
  "modify_dt" timestamp
);

DROP TABLE IF EXISTS "dim_disconnectreason";
CREATE TABLE "dim_disconnectreason" (
  "disconnect_reason" varchar PRIMARY KEY,
  "create_dt" timestamp,
  "modify_dt" timestamp
);

DROP TABLE IF EXISTS "dim_user";
CREATE TABLE "dim_user" (
  "username" varchar PRIMARY KEY,
  "ARN" varchar UNIQUE,
  "Userkey" bigint,
  "DirectoryUserId" varchar,
  "HierarchyGroupId" varchar,
  "IdentityInfoFirstName" varchar,
  "IdentityInfoLastName" varchar,
  "PhoneConfigAfterContactWorkTimeLimit" varchar,
  "PhoneConfigAutoAccept" varchar,
  "PhoneConfigDeskPhoneNumber" varchar,
  "PhoneConfigPhoneType" varchar,
  "RoutingProfileId" varchar,
  "TagsBU" varchar,
  "EffectiveStartDate" timestamp,
  "EffectiveEndDate" timestamp,
  "Active" varchar,
  "create_dt" timestamp,
  "modify_dt" timestamp
);

DROP TABLE IF EXISTS "dim_agenthierarchy";
CREATE TABLE "dim_agenthierarchy" (
  "id" varchar PRIMARY KEY,
  "LevelId" varchar,
  "Name" varchar,
  "Arn" varchar,
  "HierarchyPathLevelFiveArn" varchar,
  "HierarchyPathLevelFiveId" varchar,
  "HierarchyPathLevelFiveName" varchar,
  "HierarchyPathLevelFourArn" varchar,
  "HierarchyPathLevelFourId" varchar,
  "HierarchyPathLevelFourName" varchar,
  "HierarchyPathLevelOneArn" varchar,
  "HierarchyPathLevelOneId" varchar,
  "HierarchyPathLevelOneName" varchar,
  "HierarchyPathLevelThreeArn" varchar,
  "HierarchyPathLevelThreeId" varchar,
  "HierarchyPathLevelThreeName" varchar,
  "HierarchyPathLevelTwoArn" varchar,
  "HierarchyPathLevelTwoId" varchar,
  "HierarchyPathLevelTwoName" varchar,
  "EffectiveStartDate" timestamp,
  "EffectiveEndDate" timestamp,
  "Active" varchar,
  "create_dt" timestamp,
  "modify_dt" timestamp
);

DROP TABLE IF EXISTS "dim_date";
CREATE TABLE "dim_date" (
  "dateint" int PRIMARY KEY,
  "calender_date" date,
  "calender_year" int,
  "calender_month" int,
  "month_of_year" int,
  "create_dt" timestamp,
  "modify_dt" timestamp
);

DROP TABLE IF EXISTS "dim_time";
CREATE TABLE "dim_time" (
  "time_key" int PRIMARY KEY,
  "hour" int,
  "minute" int,
  "second" int,
  "create_dt" timestamp,
  "modify_dt" timestamp
);

DROP TABLE IF EXISTS "fact_ctr_daily";
CREATE TABLE "fact_ctr_daily" (
  "date_key" int,
  "disconnect_date_key" int,
  "queue_name" varchar,
  "routingprofile_name" varchar,
  "channel_name" varchar,
  "initiation_method" varchar,
  "mediastream_type" varchar,
  "disconnect_reason" varchar,
  "username" varchar,
  "agenthierarchy_id" varchar,
  "after_contact_work_time" int,
  "agent_interaction_duration" int,
  "customer_hold_time" int,
  "contact_handle_time" int,
  "retry_callback_attempt_count" int,
  "callback_contacts_count" int,
  "contact_flow_time" int,
  "contacts_abandoned_count" int,
  "contacts_abandoned_queue_time" int,
  "contacts_answered_queue_time" int,
  "contacts_disconnectedbyagent_while_on_hold" int,
  "contacts_disconnectedbycustomer_while_on_hold" int,
  "contact_on_hold_count" int,
  "contacts_queued_count" int,
  "contacts_transferred_out_count" int,
  "contacts_transferred_out_byagent_count" int,
  "contact_time_in_queue" int,
  "create_dt" timestamp,
  "modify_dt" timestamp
);

DROP TABLE IF EXISTS "fact_ctr_monthly";
CREATE TABLE "fact_ctr_monthly" (
  "month_key" int,
  "disconnect_month_key" int,
  "queue_name" varchar,
  "routingprofile_name" varchar,
  "channel_name" varchar,
  "initiation_method" varchar,
  "mediastream_type" varchar,
  "disconnect_reason" varchar,
  "username" varchar,
  "agenthierarchy_id" varchar,
  "after_contact_work_time" int,
  "agent_interaction_duration" int,
  "customer_hold_time" int,
  "contact_handle_time" int,
  "retry_callback_attempt_count" int,
  "callback_contacts_count" int,
  "contact_flow_time" int,
  "contacts_abandoned_count" int,
  "contacts_abandoned_queue_time" int,
  "contacts_answered_queue_time" int,
  "contacts_disconnectedbyagent_while_on_hold" int,
  "contacts_disconnectedbycustomer_while_on_hold" int,
  "contact_on_hold_count" int,
  "contacts_queued_count" int,
  "contacts_transferred_out_count" int,
  "contacts_transferred_out_byagent_count" int,
  "contact_time_in_queue" int,
  "create_dt" timestamp,
  "modify_dt" timestamp
);
-- End table configuration.


-- Begin foreign key configuration.
ALTER TABLE "ctr_attributes" DROP CONSTRAINT IF EXISTS "ctr_attributes_contact_id_LastUpdateTimestamp_fkey";
ALTER TABLE "ctr_attributes" ADD FOREIGN KEY ("contact_id", "LastUpdateTimestamp") REFERENCES "fact_ctr" ("contact_id", "LastUpdateTimestamp");

ALTER TABLE "ctr_recordings" DROP CONSTRAINT IF EXISTS "ctr_recordings_contact_id_LastUpdateTimestamp_fkey";
ALTER TABLE "ctr_recordings" ADD FOREIGN KEY ("contact_id", "LastUpdateTimestamp") REFERENCES "fact_ctr" ("contact_id", "LastUpdateTimestamp");

ALTER TABLE "fact_ctr" DROP CONSTRAINT IF EXISTS "fact_ctr_queue_name_fkey";
ALTER TABLE "fact_ctr" ADD FOREIGN KEY ("queue_name") REFERENCES "dim_queue" ("queue_name");

ALTER TABLE "fact_ctr" DROP CONSTRAINT IF EXISTS "fact_ctr_routingprofile_name_fkey";
ALTER TABLE "fact_ctr" ADD FOREIGN KEY ("routingprofile_name") REFERENCES "dim_routingprofile" ("routingprofile_name");

ALTER TABLE "fact_ctr" DROP CONSTRAINT IF EXISTS "fact_ctr_initiation_method_fkey";
ALTER TABLE "fact_ctr" ADD FOREIGN KEY ("initiation_method") REFERENCES "dim_initiationmethod" ("initiation_method");

ALTER TABLE "fact_ctr" DROP CONSTRAINT IF EXISTS "fact_ctr_channel_name_fkey";
ALTER TABLE "fact_ctr" ADD FOREIGN KEY ("channel_name") REFERENCES "dim_channel" ("channel_name");

ALTER TABLE "fact_ctr" DROP CONSTRAINT IF EXISTS "fact_ctr_mediastream_type_fkey";
ALTER TABLE "fact_ctr" ADD FOREIGN KEY ("mediastream_type") REFERENCES "dim_mediastreamtype" ("mediastream_type");

ALTER TABLE "fact_ctr" DROP CONSTRAINT IF EXISTS "fact_ctr_disconnect_reason_fkey";
ALTER TABLE "fact_ctr" ADD FOREIGN KEY ("disconnect_reason") REFERENCES "dim_disconnectreason" ("disconnect_reason");

ALTER TABLE "fact_ctr" DROP CONSTRAINT IF EXISTS "fact_ctr_username_fkey";
ALTER TABLE "fact_ctr" ADD FOREIGN KEY ("username") REFERENCES "dim_user" ("username");

ALTER TABLE "fact_ctr" DROP CONSTRAINT IF EXISTS "fact_ctr_agenthierarchy_id_fkey";
ALTER TABLE "fact_ctr" ADD FOREIGN KEY ("agenthierarchy_id") REFERENCES "dim_agenthierarchy" ("id");

ALTER TABLE "fact_ctr" DROP CONSTRAINT IF EXISTS "fact_ctr_dim_date_fkey";
ALTER TABLE "fact_ctr" ADD FOREIGN KEY ("date_key") REFERENCES "dim_date" ("dateint");

ALTER TABLE "fact_ctr" DROP CONSTRAINT IF EXISTS "fact_ctr_disconnect_date_key_fkey";
ALTER TABLE "fact_ctr" ADD FOREIGN KEY ("disconnect_date_key") REFERENCES "dim_date" ("dateint");

ALTER TABLE "fact_ctr" DROP CONSTRAINT IF EXISTS "fact_ctr_dim_queue_fkey";
ALTER TABLE "fact_ctr" ADD FOREIGN KEY ("time_key") REFERENCES "dim_time" ("time_key");

ALTER TABLE "fact_ctr" DROP CONSTRAINT IF EXISTS "fact_ctr_time_key_fkey";
ALTER TABLE "fact_ctr" ADD FOREIGN KEY ("disconnect_time_key") REFERENCES "dim_time" ("time_key");

ALTER TABLE "fact_ctr_daily" DROP CONSTRAINT IF EXISTS "fact_ctr_queue_name_fkey";
ALTER TABLE "fact_ctr_daily" ADD FOREIGN KEY ("queue_name") REFERENCES "dim_queue" ("queue_name");

ALTER TABLE "fact_ctr_daily" DROP CONSTRAINT IF EXISTS "fact_ctr_routingprofile_name_fkey";
ALTER TABLE "fact_ctr_daily" ADD FOREIGN KEY ("routingprofile_name") REFERENCES "dim_routingprofile" ("routingprofile_name");

ALTER TABLE "fact_ctr_daily" DROP CONSTRAINT IF EXISTS "fact_ctr_initiation_method_fkey";
ALTER TABLE "fact_ctr_daily" ADD FOREIGN KEY ("initiation_method") REFERENCES "dim_initiationmethod" ("initiation_method");

ALTER TABLE "fact_ctr_daily" DROP CONSTRAINT IF EXISTS "fact_ctr_channel_name_fkey";
ALTER TABLE "fact_ctr_daily" ADD FOREIGN KEY ("channel_name") REFERENCES "dim_channel" ("channel_name");

ALTER TABLE "fact_ctr_daily" DROP CONSTRAINT IF EXISTS "fact_ctr_mediastream_type_fkey";
ALTER TABLE "fact_ctr_daily" ADD FOREIGN KEY ("mediastream_type") REFERENCES "dim_mediastreamtype" ("mediastream_type");

ALTER TABLE "fact_ctr_daily" DROP CONSTRAINT IF EXISTS "fact_ctr_disconnect_reason_fkey";
ALTER TABLE "fact_ctr_daily" ADD FOREIGN KEY ("disconnect_reason") REFERENCES "dim_disconnectreason" ("disconnect_reason");

ALTER TABLE "fact_ctr_daily" DROP CONSTRAINT IF EXISTS "fact_ctr_date_key_fkey";
ALTER TABLE "fact_ctr_daily" ADD FOREIGN KEY ("date_key") REFERENCES "dim_date" ("dateint");

ALTER TABLE "fact_ctr_daily" DROP CONSTRAINT IF EXISTS "fact_ctr_disconnect_date_key_fkey";
ALTER TABLE "fact_ctr_daily" ADD FOREIGN KEY ("disconnect_date_key") REFERENCES "dim_date" ("dateint");

ALTER TABLE "fact_ctr_daily" DROP CONSTRAINT IF EXISTS "fact_ctr_username_fkey";
ALTER TABLE "fact_ctr_daily" ADD FOREIGN KEY ("username") REFERENCES "dim_user" ("username");

ALTER TABLE "fact_ctr_daily" DROP CONSTRAINT IF EXISTS "fact_ctr_agenthierarchy_id_fkey";
ALTER TABLE "fact_ctr_daily" ADD FOREIGN KEY ("agenthierarchy_id") REFERENCES "dim_agenthierarchy" ("id");

ALTER TABLE "fact_ctr_monthly" DROP CONSTRAINT IF EXISTS "fact_ctr_queue_name_fkey";
ALTER TABLE "fact_ctr_monthly" ADD FOREIGN KEY ("queue_name") REFERENCES "dim_queue" ("queue_name");

ALTER TABLE "fact_ctr_monthly" DROP CONSTRAINT IF EXISTS "fact_ctr_routingprofile_name_fkey";
ALTER TABLE "fact_ctr_monthly" ADD FOREIGN KEY ("routingprofile_name") REFERENCES "dim_routingprofile" ("routingprofile_name");

ALTER TABLE "fact_ctr_monthly" DROP CONSTRAINT IF EXISTS "fact_ctr_initiation_method_fkey";
ALTER TABLE "fact_ctr_monthly" ADD FOREIGN KEY ("initiation_method") REFERENCES "dim_initiationmethod" ("initiation_method");

ALTER TABLE "fact_ctr_monthly" DROP CONSTRAINT IF EXISTS "fact_ctr_channel_name_fkey";
ALTER TABLE "fact_ctr_monthly" ADD FOREIGN KEY ("channel_name") REFERENCES "dim_channel" ("channel_name");

ALTER TABLE "fact_ctr_monthly" DROP CONSTRAINT IF EXISTS "fact_ctr_mediastream_type_fkey";
ALTER TABLE "fact_ctr_monthly" ADD FOREIGN KEY ("mediastream_type") REFERENCES "dim_mediastreamtype" ("mediastream_type");

ALTER TABLE "fact_ctr_monthly" DROP CONSTRAINT IF EXISTS "fact_ctr_disconnect_reason_fkey";
ALTER TABLE "fact_ctr_monthly" ADD FOREIGN KEY ("disconnect_reason") REFERENCES "dim_disconnectreason" ("disconnect_reason");

ALTER TABLE "fact_ctr_monthly" DROP CONSTRAINT IF EXISTS "fact_ctr_username_fkey";
ALTER TABLE "fact_ctr_monthly" ADD FOREIGN KEY ("username") REFERENCES "dim_user" ("username");

ALTER TABLE "fact_ctr_monthly" DROP CONSTRAINT IF EXISTS "fact_ctr_agenthierarchy_id_fkey";
ALTER TABLE "fact_ctr_monthly" ADD FOREIGN KEY ("agenthierarchy_id") REFERENCES "dim_agenthierarchy" ("id");

--ALTER TABLE "fact_ctr_daily" ADD FOREIGN KEY ("contacts_queued_count") REFERENCES "fact_ctr_daily" ("contacts_transferred_out_byagent_count");
-- End foreign key configuration.


-- Begin functions for maintaining create/modify timestamps.
CREATE OR REPLACE LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION update_create_timestamp()
  RETURNS TRIGGER AS $$
  BEGIN
    NEW.create_dt = clock_timestamp();
    RETURN NEW;
  END;
  $$
  language 'plpgsql';

CREATE OR REPLACE FUNCTION update_modify_timestamp()
  RETURNS TRIGGER AS $$
  BEGIN
    NEW.modify_dt = clock_timestamp();
    RETURN NEW;
  END;
  $$
  language 'plpgsql';
-- End functions for maintaining create/modify timestamps.


-- Begin triggers to write create_dt timestamps.
CREATE OR REPLACE TRIGGER fact_ctr_create_dt
  BEFORE INSERT ON fact_ctr
  FOR EACH ROW EXECUTE PROCEDURE update_create_timestamp();

CREATE OR REPLACE TRIGGER ctr_recordings_create_dt
  BEFORE INSERT ON ctr_recordings
  FOR EACH ROW EXECUTE PROCEDURE update_create_timestamp();

CREATE OR REPLACE TRIGGER ctr_attributes_create_dt
  BEFORE INSERT ON ctr_attributes
  FOR EACH ROW EXECUTE PROCEDURE update_create_timestamp();

CREATE OR REPLACE TRIGGER dim_queue_create_dt
  BEFORE INSERT ON dim_queue
  FOR EACH ROW EXECUTE PROCEDURE update_create_timestamp();

CREATE OR REPLACE TRIGGER dim_routingprofile_create_dt
  BEFORE INSERT ON dim_routingprofile
  FOR EACH ROW EXECUTE PROCEDURE update_create_timestamp();

CREATE OR REPLACE TRIGGER dim_initiationmethod_create_dt
  BEFORE INSERT ON dim_initiationmethod
  FOR EACH ROW EXECUTE PROCEDURE update_create_timestamp();

CREATE OR REPLACE TRIGGER dim_channel_create_dt
  BEFORE INSERT ON dim_channel
  FOR EACH ROW EXECUTE PROCEDURE update_create_timestamp();

CREATE OR REPLACE TRIGGER dim_mediastreamtype_create_dt
  BEFORE INSERT ON dim_mediastreamtype
  FOR EACH ROW EXECUTE PROCEDURE update_create_timestamp();

CREATE OR REPLACE TRIGGER dim_disconnectreason_create_dt
  BEFORE INSERT ON dim_disconnectreason
  FOR EACH ROW EXECUTE PROCEDURE update_create_timestamp();

CREATE OR REPLACE TRIGGER dim_agenthierarchy_create_dt
  BEFORE INSERT ON dim_agenthierarchy
  FOR EACH ROW EXECUTE PROCEDURE update_create_timestamp();

CREATE OR REPLACE TRIGGER dim_date_create_dt
  BEFORE INSERT ON dim_date
  FOR EACH ROW EXECUTE PROCEDURE update_create_timestamp();

CREATE OR REPLACE TRIGGER dim_time_create_dt
  BEFORE INSERT ON dim_time
  FOR EACH ROW EXECUTE PROCEDURE update_create_timestamp();
-- End triggers to write create_dt timestamps.


-- Begin triggers to write modify_dt timestamps.
CREATE OR REPLACE TRIGGER fact_ctr_modify_dt
  BEFORE INSERT OR UPDATE ON fact_ctr
  FOR EACH ROW EXECUTE PROCEDURE update_modify_timestamp();

CREATE OR REPLACE TRIGGER ctr_recordings_modify_dt
  BEFORE INSERT OR UPDATE ON ctr_recordings
  FOR EACH ROW EXECUTE PROCEDURE update_modify_timestamp();

CREATE OR REPLACE TRIGGER ctr_attributes_modify_dt
  BEFORE INSERT OR UPDATE ON ctr_attributes
  FOR EACH ROW EXECUTE PROCEDURE update_modify_timestamp();

CREATE OR REPLACE TRIGGER dim_queue_modify_dt
  BEFORE INSERT OR UPDATE ON dim_queue
  FOR EACH ROW EXECUTE PROCEDURE update_modify_timestamp();

CREATE OR REPLACE TRIGGER dim_routingprofile_modify_dt
  BEFORE INSERT OR UPDATE ON dim_routingprofile
  FOR EACH ROW EXECUTE PROCEDURE update_modify_timestamp();

CREATE OR REPLACE TRIGGER dim_initiationmethod_modify_dt
  BEFORE INSERT OR UPDATE ON dim_initiationmethod
  FOR EACH ROW EXECUTE PROCEDURE update_modify_timestamp();

CREATE OR REPLACE TRIGGER dim_channel_modify_dt
  BEFORE INSERT OR UPDATE ON dim_channel
  FOR EACH ROW EXECUTE PROCEDURE update_modify_timestamp();

CREATE OR REPLACE TRIGGER dim_mediastreamtype_modify_dt
  BEFORE INSERT OR UPDATE ON dim_mediastreamtype
  FOR EACH ROW EXECUTE PROCEDURE update_modify_timestamp();

CREATE OR REPLACE TRIGGER dim_disconnectreason_modify_dt
  BEFORE INSERT OR UPDATE ON dim_disconnectreason
  FOR EACH ROW EXECUTE PROCEDURE update_modify_timestamp();

CREATE OR REPLACE TRIGGER dim_agenthierarchy_modify_dt
  BEFORE INSERT OR UPDATE ON dim_agenthierarchy
  FOR EACH ROW EXECUTE PROCEDURE update_modify_timestamp();

CREATE OR REPLACE TRIGGER dim_date_modify_dt
  BEFORE INSERT OR UPDATE ON dim_date
  FOR EACH ROW EXECUTE PROCEDURE update_modify_timestamp();

CREATE OR REPLACE TRIGGER dim_time_modify_dt
  BEFORE INSERT OR UPDATE ON dim_time
  FOR EACH ROW EXECUTE PROCEDURE update_modify_timestamp();
-- End triggers to write modify_dt timestamps.

-- Begin static data.
INSERT INTO dim_channel (channel_name)
  VALUES
    ('VOICE'),
    ('CHAT'),
    ('TASK')
  ON CONFLICT (channel_name) DO NOTHING;

INSERT INTO dim_mediastreamtype (mediastream_type)
  VALUES
    ('AUDIO'),
    ('VIDEO'),
    ('CHAT')
  ON CONFLICT (mediastream_type) DO NOTHING;

INSERT INTO dim_disconnectreason (disconnect_reason)
  VALUES
    ('CUSTOMER_DISCONNECT'),
    ('AGENT_DISCONNECT'),
    ('THIRD_PARTY_DISCONNECT'),
    ('TELECOM_PROBLEM'),
    ('BARGED'),
    ('CONTACT_FLOW_DISCONNECT'),
    ('EXPIRED'),
    ('API'),
    ('OTHER')
  ON CONFLICT (disconnect_reason) DO NOTHING;

INSERT INTO dim_initiationmethod (initiation_method)
  VALUES
    ('INBOUND'),
    ('OUTBOUND'),
    ('TRANSFER'),
    ('CALLBACK'),
    ('API'),
    ('QUEUE_TRANSFER'),
    ('EXTERNAL_OUTBOUND'),
    ('MONITOR'),
    ('DISCONNECT')
  ON CONFLICT (initiation_method) DO NOTHING;
-- End static data.


-- Begin user management.
-- Passwords may not be be set here even in implicit form.
-- This file is destined for S3 and that is not an appropriate place to store them.
-- CREATE ROLE "lambda" LOGIN;
-- GRANT pg_read_all_data TO "lambda";
-- GRANT pg_write_all_data TO "lambda";
-- End user management.
