DROP TABLE IF EXISTS fact_evaluation_forms CREATE TABLE fact_evaluation_forms (
    evaluation_id UUID,
    contact_id UUID,
    account_id VARCHAR,
    instance_id UUID,
    agent_id UUID,
    evaluation_definition_title VARCHAR,
    evaluator VARCHAR,
    evaluation_definition_id UUID,
    evaluation_definition_version VARCHAR,
    evaluation_start_timestamp TIMESTAMP WITH TIME ZONE,
    evaluation_submit_timestamp TIMESTAMP WITH TIME ZONE,
    score_percentage DECIMAL,
    create_dt TIMESTAMP WITH TIME ZONE,
    modify_dt TIMESTAMP WITH TIME ZONE,
    PRIMARY KEY (evaluation_id)
);

GRANT
SELECT
,
INSERT
,
UPDATE
,
    DELETE ON fact_evaluation_forms TO PUBLIC;

CREATE TABLE fact_evaluation_forms_sections (
    section_ref_id VARCHAR,
    evaluation_id VARCHAR,
    section_title VARCHAR,
    parent_section_ref_id VARCHAR,
    score_percentage decimal,
    create_dt TIMESTAMP WITH TIME ZONE,
    modify_dt TIMESTAMP WITH TIME ZONE,
    PRIMARY KEY (section_ref_id, evaluation_id),
    FOREIGN KEY (evaluation_id) REFERENCES fact_evaluation_forms(evaluation_id)
);

GRANT
SELECT
,
INSERT
,
UPDATE
,
    DELETE ON fact_evaluation_forms_sections TO PUBLIC;

CREATE TABLE fact_evaluation_forms_questions (
    evaluation_id VARCHAR,
    question_ref_id VARCHAR,
    section_ref_id VARCHAR,
    question_type VARCHAR,
    question_text VARCHAR,
    answer_notes VARCHAR,
    answer_metadata_not_applicable BOOLEAN,
    answer_metadata_automation_system_suggested_value VARCHAR,
    answer_metadata_automation_status VARCHAR,
    score_percentage DECIMAL,
    create_dt TIMESTAMP WITH TIME ZONE,
    modify_dt TIMESTAMP WITH TIME ZONE,
    PRIMARY KEY (evaluation_id, question_ref_id, section_ref_id),
    FOREIGN KEY (evaluation_id) REFERENCES fact_evaluation_forms(evaluation_id),
    FOREIGN KEY (section_ref_id, evaluation_id) REFERENCES fact_evaluation_forms_sections(section_ref_id, evaluation_id)
);

GRANT
SELECT
,
INSERT
,
UPDATE
,
    DELETE ON fact_evaluation_forms_questions TO PUBLIC;

CREATE TABLE fact_evaluation_forms_answer_values(
    evaluation_id VARCHAR,
    question_ref_id VARCHAR,
    section_ref_id VARCHAR,
    value_ref_id VARCHAR,
    value_text VARCHAR,
    selected BOOLEAN,
    create_dt TIMESTAMP WITH TIME ZONE,
    modify_dt TIMESTAMP WITH TIME ZONE,
    PRIMARY KEY (
        evaluation_id,
        question_ref_id,
        section_ref_id,
        value_ref_id
    ),
    FOREIGN KEY (evaluation_id) REFERENCES fact_evaluation_forms(evaluation_id),
    FOREIGN KEY (section_ref_id, evaluation_id) REFERENCES fact_evaluation_forms_sections(section_ref_id, evaluation_id),
    FOREIGN KEY (evaluation_id, question_ref_id, section_ref_id) REFERENCES fact_evaluation_forms_questions(evaluation_id, question_ref_id, section_ref_id)
);

GRANT
SELECT
,
INSERT
,
UPDATE
,
    DELETE ON fact_evaluation_forms_answer_values TO PUBLIC;