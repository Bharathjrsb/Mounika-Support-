CREATE TABLE generic (
    schemaVersion TEXT,
    evaluationId TEXT,
    contactId TEXT,
    accountId TEXT,
    instanceId TEXT,
    agentId TEXT,
    evaluationDefinitionTitle TEXT,
    evaluator TEXT,
    evaluationDefinitionId TEXT,
    evaluationDefinitionVersion INT,
    evaluationStartTimestamp TIMESTAMP,
    evaluationSubmitTimestamp TIMESTAMP,
    PRIMARY KEY (evaluationId)
);

CREATE TABLE generic_metadata_score (
    evaluationId TEXT,
    percentage INT,
    PRIMARY KEY (evaluationId),
    FOREIGN KEY (generic_metadata_id) REFERENCES generic_metadata(evaluationId)
);

CREATE TABLE generic_sections (
    evaluationId TEXT,
    sectionRefId TEXT,
    sectionTitle TEXT,
    PRIMARY KEY (evaluationId),
    FOREIGN KEY (evaluationId) REFERENCES generic(evaluationId)
);

CREATE TABLE generic_sections_score (
    generic_sections_id TEXT,
    percentage INT,
    PRIMARY KEY (evaluationId),
    FOREIGN KEY (generic_sections_id) REFERENCES generic_sections(evaluationId)
);

CREATE TABLE generic_questions (
    evaluationId TEXT,
    questionRefId TEXT,
    sectionRefId TEXT,
    questionType TEXT,
    questionText TEXT,
    PRIMARY KEY (evaluationId),
    FOREIGN KEY (evaluationId) REFERENCES generic(evaluationId)
);

CREATE TABLE generic_questions_answer (
    generic_questions_id TEXT,
    notes TEXT,
    PRIMARY KEY (evaluationId),
    FOREIGN KEY (generic_questions_id) REFERENCES generic_questions(evaluationId)
);

CREATE TABLE generic_questions_answer_values (
    generic_questions_answer_id TEXT,
    valueText TEXT,
    valueRefId TEXT,
    selected BOOLEAN,
    PRIMARY KEY (evaluationId),
    FOREIGN KEY (generic_questions_answer_id) REFERENCES generic_questions_answer(evaluationId)
);

CREATE TABLE generic_questions_answer_metadata (
    generic_questions_answer_id TEXT,
    notApplicable BOOLEAN,
    PRIMARY KEY (evaluationId),
    FOREIGN KEY (generic_questions_answer_id) REFERENCES generic_questions_answer(evaluationId)
);

CREATE TABLE generic_questions_answer_metadata_automation (
    generic_questions_answer_metadata_id TEXT,
    systemSuggestedValue TEXT,
    STATUS TEXT,
    PRIMARY KEY (evaluationId),
    FOREIGN KEY (generic_questions_answer_metadata_id) REFERENCES generic_questions_answer_metadata(evaluationId)
);

CREATE TABLE generic_questions_score (
    generic_questions_id TEXT,
    percentage INT,
    PRIMARY KEY (evaluationId),
    FOREIGN KEY (generic_questions_id) REFERENCES generic_questions(evaluationId)
);