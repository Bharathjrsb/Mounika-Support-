import {expect, jest} from '@jest/globals';
import lambda_env from '../lambda-env';
import * as lp from "logplease";
import { camelCaseToUnderscores } from '../../src/util/misc.mjs';
const Logger = lp.default.create("Logger", { showTimestamp: false, useColors: false });
import { EventEmitter } from 'events';
jest.mock('@aws-sdk/client-s3');
jest.mock('pg');

import { SecretsManager } from "@aws-sdk/client-secrets-manager";
import { S3 } from '@aws-sdk/client-s3';

jest.mock('@aws-sdk/client-secrets-manager', () => {
    return {
      __esModule: true,
      SecretsManager: jest.fn(() => ({
        getSecretValue:  jest.fn().mockResolvedValue({
            SecretString: JSON.stringify({
              username: 'test',
              password: 'test',
            }),
          }),
      })),
    };
  });


  const ctr_event_Template = await import('../sample-events/example_ctr_event.json');

  const res_Success = {
    Body : {transformToString : jest.fn().mockResolvedValue(JSON.stringify(ctr_event_Template.default)),
    ...ctr_event_Template.default}
  };

  const res_Failure = {
    Body : {transformToString : jest.fn().mockResolvedValue("GARBAGE DATA"),
     ...ctr_event_Template.default }
  };

  const { S3Client, GetObjectCommand } = await import ("@aws-sdk/client-s3");



  jest.mock('@aws-sdk/client-s3', () => {
    return {
      __esModule: true,
      S3Client: jest.fn(() => ({
        send : jest.fn().mockResolvedValue(res_Success)
      })),
      GetObjectCommand : jest.fn(() => {})
    }
    
    });


/*
  jest.mock('@aws-sdk/client-s3', () => {
  return {
    __esModule: true,
    S3Client: jest.fn(() => ({
      send : jest.fn().mockResolvedValue({
        Body : {transformToString : jest.fn().mockResolvedValue(JSON.stringify(ctr_event_Template.default)),
        ...ctr_event_Template.default}
      })
    })),
    GetObjectCommand : jest.fn(() => {})
  }
  
  });
*/
let env_backup;
let lambda;
let processOnSpy;

const eventbridge_event_Template = await import('../sample-events/example_eventbridge_s3_put.json');
let successful_event;

let res_payload;

describe('common tests', ()=> {


    beforeAll( async () => {
//Set static variables
        env_backup = process.env;
        process.env = lambda_env;
        process.env.S3_BUCKET_CLOUDWATCH_LOGS = "cloudwatch-logs";

         lambda = await import('../../src/index.mjs');
    });

    afterAll( () => {
        // Restore env variables.
        process.env = env_backup;

    });

    beforeEach( async () => {     

        // Reset sample events.
        successful_event = structuredClone(eventbridge_event_Template.default);
        S3Client.prototype.send.mockResolvedValue(res_Success)
        processOnSpy = jest.spyOn(process, 'on');

    });

    test('Basic Test', async () => { //should be able to run through the whole lambda without erroring
        
     

        const lambda_res = await lambda.handler(successful_event);

        expect(lambda_res).toEqual({ "LambdaSuccess": true, "message": `${[ctr_event_Template.default[2].ContactId]} insert successful.`,})

    })

    test('EventBridge unmatched type event Test', async () => {

      let error_event = structuredClone(successful_event);
      
      error_event.source = "Not a recognized source";

      const lambda_res = await lambda.handler(error_event);

      expect(lambda_res).toEqual({ "LambdaSuccess": false, "message": `Eventbridge event type unmatched: event.source=${error_event.source}, event.detail-type=${error_event["detail-type"]}`,})

  })

  test('Cloudwatch Logs Test', async () => {
    let test_event = structuredClone(successful_event);
    test_event.detail.bucket.name = "cloudwatch-logs";
    const lambda_res = await lambda.handler(test_event);
    expect(lambda_res).toBeUndefined();
  })

 
test('Unexpected bucket source Test', async () => {

  let error_event = structuredClone(successful_event);

  let context = {awsRequestId : "RCS52XWXB9H48WW3"};

  error_event.detail.bucket.name = "Not a real bucket";

//const lambda_res = await lambda.handler(error_event, context);

let message = `Unknown bucket source ${error_event.detail.bucket.name}.`;

        // throw the error. Build the Error message so the log can be downloaded easily. It will be sent to the SNS in the future as well.
        const region = process.env.AWS_REGION;
        const logGroupName = process.env.AWS_LAMBDA_LOG_GROUP_NAME;
        const logStreamName = process.env.AWS_LAMBDA_LOG_STREAM_NAME;
        const requestId = context.awsRequestId;
        // I hope no-one need to do this in the future..
        const cwUrl =
          `https://${region}.console.aws.amazon.com/cloudwatch/home?region=${region}#logsV2:log-groups/log-group/` +
          `${encodeURIComponent(encodeURIComponent(logGroupName)).replaceAll("%", "$")}` +
          `/log-events/` +
          `${encodeURIComponent(encodeURIComponent(logStreamName)).replaceAll("%", "$")}` +
          `${encodeURIComponent("?filterPattern=").replaceAll("%", "$")}` +
          `${encodeURIComponent(encodeURIComponent("%" + requestId + "%")).replaceAll("%", "$")}`;


          message = message + `cwUrl= ${cwUrl}`;

await expect(() =>lambda.handler(error_event,context)).rejects.toThrowError(message);

})


test('Bad Response Test', async () => {

  let error_event = structuredClone(successful_event);

  let context = {awsRequestId : "RCS52XWXB9H48WW3"};

  S3Client.prototype.send.mockResolvedValue(res_Failure)

await expect(() =>lambda.handler(error_event,context)).rejects.toThrowError();
})

test('Cloudwatch Events Error Handling', async () => {
  S3Client.prototype.send.mockRejectedValueOnce(new Error("Not implemented => Cloudwatch Events"));
  const lambda_res = await lambda.handler(successful_event);
  expect(lambda_res).toEqual({ "LambdaSuccess": false, "message": "Not implemented => Cloudwatch Events",})

});

test('CamelCase to Underscores Test', async () => {
    const input = "camelCaseToUnderscores";
    const output = "camel_case_to_underscores";
    expect(camelCaseToUnderscores(input)).toEqual(output);
})

test('Process receives SIGTERM', async () => {
  const mockExit = jest.spyOn(process, 'exit').mockImplementation(() => {});
    process.emit('SIGTERM');
  });

})
