import { jest } from '@jest/globals';
import lambda_env from '../lambda-env';
import * as lp from "logplease";

const Logger = lp.default.create("Logger", { showTimestamp: false, useColors: false });
jest.mock('@aws-sdk/client-s3');

jest.mock('pg');
const pg = await import('pg');

let mock_query = jest.fn(item => new Promise(resolve => {
  return resolve({
    status: "fulfilled",
    reason: "Its a test",
    value: { rowcount: item.values.length }
  })
}));



import { SecretsManager } from "@aws-sdk/client-secrets-manager";


jest.mock('@aws-sdk/client-secrets-manager', () => {
  return {
    __esModule: true,
    SecretsManager: jest.fn(() => ({
      getSecretValue: jest.fn().mockResolvedValue({
        SecretString: JSON.stringify({
          username: 'test',
          password: 'test',
        }),
      }),
    })),
  };
});

const { S3Client, GetObjectCommand } = await import("@aws-sdk/client-s3");
const agent_event_Template = await import('../sample-events/example_agent_event.json');
const agent_hierarchy_event_Template = await import('../sample-events/example_agent_event_hierarhcy.json');

const res_Success = {
  Body: {
    transformToString: jest.fn().mockResolvedValue(JSON.stringify(agent_event_Template.default)),
    ...agent_event_Template.default
  }
};

const res_Hierarchy_Success = {
  Body: {
    transformToString: jest.fn().mockResolvedValue(JSON.stringify(agent_hierarchy_event_Template.default)),
    ...agent_hierarchy_event_Template.default
  }
};

jest.mock('@aws-sdk/client-s3', () => {
  return {
    __esModule: true,
    S3Client: jest.fn(() => ({
      send: jest.fn().mockResolvedValue(res_Success)
    })),
    GetObjectCommand: jest.fn(() => { })
  }

});

const eventbridge_event_Template = await import('../sample-events/example_eventbridge_s3_put.json');
let env_backup;
let lambda;
let successful_event;



describe('update agent tests', () => {


  beforeAll(async () => {
    //Set static variables
    env_backup = process.env;
    process.env = lambda_env;

    // Client.Client.prototype.query = mock_query;

    pg.default.Client.mockImplementation(() => ({
      __esModule: true,
      end: jest.fn(),
      tryConnect: jest.fn(),
      query: mock_query

    }));

    lambda = await import('../../src/index.mjs');
  });

  afterAll(() => {
    // Restore env variables.
    process.env = env_backup;

  });

  beforeEach(async () => {
    // Reset sample events.
    successful_event = structuredClone(eventbridge_event_Template.default);
    successful_event.detail.bucket.name = "gwe1-connect-agent-event-raw-dv1-s3"


    S3Client.prototype.send.mockResolvedValue(res_Success)
  });

  test('Successful Test', async () => {

    const lambda_res = await lambda.handler(successful_event);

    expect(lambda_res).toEqual({ "LambdaSuccess": true, "message": "Agent Event Insert successful.", });
  })

  test('single event Test', async () => {


    let res_Success_Single = {
      Body: {
        transformToString: jest.fn().mockResolvedValue(JSON.stringify(agent_event_Template.default[0])),
        ...agent_event_Template.default
      }
    };

    S3Client.prototype.send.mockResolvedValue(res_Success_Single)

    const lambda_res = await lambda.handler(successful_event);

    expect(lambda_res).toEqual({ "LambdaSuccess": true, "message": "Agent Event Insert successful.", });
  })

  test('Bad Data Test', async () => {

    let testData = agent_event_Template.default[0];
    delete testData.EventType;

    let res_Success_Single = {
      Body: {
        transformToString: jest.fn().mockResolvedValue(JSON.stringify(testData)),
        ...testData
      }
    };

    S3Client.prototype.send.mockResolvedValue(res_Success_Single);

    await expect(() => lambda.handler(successful_event, { awsRequestId: "TestID" })).rejects.toThrowError();
  })

  test('Agent Hierarchy Test', async () => {
    S3Client.prototype.send.mockResolvedValue(res_Hierarchy_Success);

    const lambda_res = await lambda.handler(successful_event);

    expect(lambda_res).toEqual({ "LambdaSuccess": true, "message": "Agent Event Insert successful.", });
  })


  test('Missing Event Type Test', async () => {
    let testData = agent_event_Template.default;
    delete testData[0].EventType;

    let res_Failure = {
      Body: {
        transformToString: jest.fn().mockResolvedValue(JSON.stringify(testData)),
        ...testData
      }
    };

    S3Client.prototype.send.mockResolvedValueOnce(res_Failure);

    const lambda_res = await lambda.handler(successful_event);

    expect(lambda_res).toEqual({ "LambdaSuccess": true, "message": "Agent Event Insert partially successful." })
  })

  // test('concurrencyArray is not an array', async () => {

  //   const oldVal = agent_event_Template.default[0].CurrentAgentSnapshot.Configuration.RoutingProfile.Concurrency;
  //   agent_event_Template.default[0].CurrentAgentSnapshot.Configuration.RoutingProfile.Concurrency = "test";
  //   let res_Success_Single = {
  //     Body: {
  //       transformToString: jest.fn().mockResolvedValue(JSON.stringify(agent_event_Template.default)),
  //       ...agent_event_Template.default
  //     }
  //   };

  //   S3Client.prototype.send.mockResolvedValue(res_Success_Single)

  //   const lambda_res = await lambda.handler(successful_event);
  //   agent_event_Template.default[0].CurrentAgentSnapshot.Configuration.RoutingProfile.Concurrency = oldVal;

  //   expect(lambda_res).toEqual({ "LambdaSuccess": true, "message": "Agent Event Insert successful.", });
  // })

})