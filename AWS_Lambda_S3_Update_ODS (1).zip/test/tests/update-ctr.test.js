import {jest} from '@jest/globals';
import lambda_env from '../lambda-env';
import * as lp from "logplease";
import {flattenedAttributesQueryConstructor} from '../../src/update-ctr.mjs'
const Logger = lp.default.create("Logger", { showTimestamp: false, useColors: false });
jest.mock('@aws-sdk/client-s3');
jest.mock('pg');

import { SecretsManager } from "@aws-sdk/client-secrets-manager";

jest.mock('@aws-sdk/client-secrets-manager', () => {
    return {
      __esModule: true,
      SecretsManager: jest.fn(() => ({
        getSecretValue:  jest.fn().mockResolvedValue({
            SecretString: JSON.stringify({
              username: 'test',
              password: 'test',
            }),
          }),
      })),
    };
  });

  const { S3Client, GetObjectCommand } = await import ("@aws-sdk/client-s3");

  const ctr_event_Template = await import('../sample-events/example_ctr_event.json');
  const single_record_event_Template = await import('../sample-events/single_record_ctr_event.json');
  const hierarchy_event_Template = await import('../sample-events/example_ctr_with_hierarchy.json');
  const quality_event_Template = await import('../sample-events/call_quality_ctr_event.json');


  const res_Success = {
    Body : {transformToString : jest.fn().mockResolvedValue(JSON.stringify(ctr_event_Template.default)),
    ...ctr_event_Template.default}
  };

  const res_Single_Record = {
    Body : {transformToString : jest.fn().mockResolvedValue(JSON.stringify(single_record_event_Template.default)),
    ...single_record_event_Template.default}
  };

  const res_Hierarchy_Record = {
    Body : {transformToString : jest.fn().mockResolvedValue(JSON.stringify(hierarchy_event_Template.default)),
    ...hierarchy_event_Template.default}
  };
  
  const res_Quality_Record = {
    Body : {transformToString : jest.fn().mockResolvedValue(JSON.stringify(quality_event_Template.default)),
    ...quality_event_Template.default}
  };
  
  jest.mock('@aws-sdk/client-s3', () => {
    return {
      __esModule: true,
      S3Client: jest.fn(() => ({
        send : jest.fn().mockResolvedValue(res_Success)
      })),
      GetObjectCommand : jest.fn(() => {})
    }
    
    });



let env_backup;
let lambda;

const eventbridge_event_Template = await import('../sample-events/example_eventbridge_s3_put.json');
let successful_event;




describe('update ctr tests', ()=> {


    beforeAll( async () => {
        //Set static variables
                env_backup = process.env;
                process.env = lambda_env;
        
                 lambda = await import('../../src/index.mjs');
            });
        
            afterAll( () => {
                // Restore env variables.
                process.env = env_backup;
        
            });
        
            beforeEach( async () =>{     
                // Reset sample events.
                successful_event = structuredClone(eventbridge_event_Template.default);
               
               S3Client.prototype.send.mockResolvedValue(res_Success)
        
            });
        
            test('Successful Test', async () => {
             
                
                const lambda_res = await lambda.handler(successful_event);
        
                expect(lambda_res).toEqual({ "LambdaSuccess": true, "message": `${[ctr_event_Template.default[2].ContactId]} insert successful.`,})
             }),

             test('Non-Array Test', async () => {
             
              S3Client.prototype.send.mockResolvedValue(res_Single_Record)

                const lambda_res = await lambda.handler(successful_event);
        
                expect(lambda_res).toEqual({ "LambdaSuccess": true, "message": `${[single_record_event_Template.default.ContactId]} insert successful.`,})
             }),

             test('Hierarchy Test', async () => {

              S3Client.prototype.send.mockResolvedValue(res_Hierarchy_Record)
                
                const lambda_res = await lambda.handler(successful_event);  
        
                expect(lambda_res).toEqual({ "LambdaSuccess": true, "message": `${[hierarchy_event_Template.default.ContactId]} insert successful.`,})
             }),

             test('Quality Test', async () => {

              S3Client.prototype.send.mockResolvedValue(res_Quality_Record)
                
                const lambda_res = await lambda.handler(successful_event);  
        
                expect(lambda_res).toEqual({ "LambdaSuccess": true, "message": `${[quality_event_Template.default.ContactId]} insert successful.`,})
             }),

            test('Default Pattern Test', async () => {
         
              const ATTRIBUTES_PATTERN_DEFAULT = ["-ods-", "ods-", "-ods", "sfdc-"];

                      const result = flattenedAttributesQueryConstructor(single_record_event_Template.default, ATTRIBUTES_PATTERN_DEFAULT);

                      expect(result).toEqual([])
                  }),


            test('Custom Pattern Test Test', async () => {
                    //implement
                    const ATTRIBUTES_PATTERN = ["-cf", "ods-", "-ods", "sfdc-"];

                    const result = flattenedAttributesQueryConstructor(single_record_event_Template.default, ATTRIBUTES_PATTERN);

                    const expected_result = [  
                      {  contact_id: '53339a08-d2a0-449e-88c6-be65a60714f3',last_update_timestamp: '2023-10-10T21:47:21Z', key: "gw_servdesk_agentWhisper-cf",value: "arn:aws:connect:us-east-1:384634809994:instance/bf6e5937-82c8-4b54-a9e9-0ff02eebe818/contact-flow/dd44d3e7-471a-4712-af76-3bfe48fd2f0f",},  
                      {  contact_id: '53339a08-d2a0-449e-88c6-be65a60714f3',last_update_timestamp: '2023-10-10T21:47:21Z', key: "gw_servdesk_customerQueue-cf",value: "arn:aws:connect:us-east-1:384634809994:instance/bf6e5937-82c8-4b54-a9e9-0ff02eebe818/contact-flow/532d4a30-e6ad-4586-9869-7f90ec891a71",},  
                      {  contact_id: '53339a08-d2a0-449e-88c6-be65a60714f3',last_update_timestamp: '2023-10-10T21:47:21Z', key:  "gw_servdesk_customerWhisper-cf",value: "arn:aws:connect:us-east-1:384634809994:instance/bf6e5937-82c8-4b54-a9e9-0ff02eebe818/contact-flow/ddfd89d7-49ac-4b31-802f-fbbbc0fb96d3",},  
                      {  contact_id: '53339a08-d2a0-449e-88c6-be65a60714f3',last_update_timestamp: '2023-10-10T21:47:21Z', key: "gw_servdesk_queueTransfer-cf",value:  "arn:aws:connect:us-east-1:384634809994:instance/bf6e5937-82c8-4b54-a9e9-0ff02eebe818/contact-flow/7d35e5ae-d746-4fa7-aa8f-408f5ab24163",},  
                      {  contact_id: '53339a08-d2a0-449e-88c6-be65a60714f3',last_update_timestamp: '2023-10-10T21:47:21Z', key: "gw_servdesk_routeIntent_dtmf-cf",value: "arn:aws:connect:us-east-1:384634809994:instance/bf6e5937-82c8-4b54-a9e9-0ff02eebe818/contact-flow/438cd70c-a2c7-42fd-9ca8-b30e0c4f9710",},  
                      {  contact_id: '53339a08-d2a0-449e-88c6-be65a60714f3',last_update_timestamp: '2023-10-10T21:47:21Z', key: "gw_servdesk_routeIntent_lex-cf",value: "arn:aws:connect:us-east-1:384634809994:instance/bf6e5937-82c8-4b54-a9e9-0ff02eebe818/contact-flow/d80d00d3-9070-4700-b22c-e60e45e0c457",},  
                    
                    ]


                    expect(result).toEqual(expected_result)
                })




})