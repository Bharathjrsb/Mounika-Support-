import {jest} from '@jest/globals';
import lambda_env from '../lambda-env';
import * as lp from "logplease";

const Logger = lp.default.create("Logger", { showTimestamp: false, useColors: false });
jest.mock('@aws-sdk/client-s3');

jest.mock('pg');
const  pg  = await import ('pg');

let mock_query = jest.fn( item =>new Promise( resolve => {
return resolve({
  status :  "fulfilled",
  reason : "Its a test",
  value : { rowcount :  item.values.length }
})
}));



import { SecretsManager } from "@aws-sdk/client-secrets-manager";


jest.mock('@aws-sdk/client-secrets-manager', () => {
    return {
      __esModule: true,
      SecretsManager: jest.fn(() => ({
        getSecretValue:  jest.fn().mockResolvedValue({
            SecretString: JSON.stringify({
              username: 'test',
              password: 'test',
            }),
          }),
      })),
    };
  });

  const { S3Client, GetObjectCommand } = await import ("@aws-sdk/client-s3");
  const form_event_Template = await import('../sample-events/example_evaluation_forms.json');
  

  const res_Success = {
    Body : {transformToString : jest.fn().mockResolvedValue(JSON.stringify(form_event_Template.default)),
    ...form_event_Template.default}
  };


  jest.mock('@aws-sdk/client-s3', () => {
    return {
      __esModule: true,
      S3Client: jest.fn(() => ({
        send : jest.fn().mockResolvedValue(res_Success)
      })),
      GetObjectCommand : jest.fn(() => {})
    }
    
    });

    const eventbridge_event_Template = await import('../sample-events/example_eventbridge_s3_put.json');
    let env_backup;
    let lambda;
    let successful_event;
    let form_event;

describe('update evaluation forms tests', ()=> {

  beforeAll( async () => {
    //Set static variables
            env_backup = process.env;
            process.env = lambda_env;

           // Client.Client.prototype.query = mock_query;

             pg.default.Client.mockImplementation(() => ({
              __esModule: true,
              end : jest.fn(),
              tryConnect : jest.fn(),
              query : mock_query

             }));
    
             lambda = await import('../../src/index.mjs');
        });
    
        afterAll( () => {
            // Restore env variables.
            process.env = env_backup;
    
        });
    
        beforeEach( async () => {     
          // Reset sample events.
          successful_event = structuredClone(eventbridge_event_Template.default);
          successful_event.detail.bucket.name = "evaluation-bucket" 
          
          form_event = structuredClone(form_event_Template.default);

      
          S3Client.prototype.send.mockResolvedValue(res_Success)
        });
        
            test('Successful Test', async () => {
        
                
                const lambda_res = await lambda.handler(successful_event, {awsRequestId : "sjhdfsdkjhfsld"});
        
                // expect(lambda_res).toEqual({ "LambdaSuccess": true, "message": "aacc0787-cbcb-47ca-94d5-8b1126205c3d|199df450-018e-4d7d-9ff0-69f003b15fd9 inserted successfully",})
            })

            test('Missing schema version Test', async () => {

              let test_data = form_event;
              delete test_data.schemaVersion

              let res_Failure = {
                Body : {transformToString : jest.fn().mockResolvedValue(JSON.stringify(test_data)),
                ...test_data}
              };

              S3Client.prototype.send.mockResolvedValue(res_Failure);
                
      
              await expect(() =>lambda.handler(successful_event, {awsRequestId : "sjhdfsdkjhfsld"})).rejects.toThrowError();
          })

          test('Missing evaluationId Test', async () => {

            let test_data = form_event;
            delete test_data.evaluationId

            let res_Failure = {
              Body : {transformToString : jest.fn().mockResolvedValue(JSON.stringify(test_data)),
              ...test_data}
            };

            S3Client.prototype.send.mockResolvedValue(res_Failure);
        
    
            await expect(() =>lambda.handler(successful_event, {awsRequestId : "sjhdfsdkjhfsld"})).rejects.toThrowError();
        })

        test('Bad data Test', async () => {

          let test_data = form_event;
           test_data.sections = "some garbage"

          let res_Failure = {
            Body : {transformToString : jest.fn().mockResolvedValue(JSON.stringify(test_data)),
            ...test_data}
          };
        
          S3Client.prototype.send.mockResolvedValue(res_Failure);
                
         
  
          await expect(() =>lambda.handler(successful_event, {awsRequestId : "sjhdfsdkjhfsld"})).rejects.toThrowError();
      })

      
})