import {jest} from '@jest/globals';
import lambda_env from '../lambda-env';
import * as lp from "logplease";

const Logger = lp.default.create("Logger", { showTimestamp: false, useColors: false });
jest.mock('@aws-sdk/client-s3');

const mockClient = {
  query: jest.fn().mockResolvedValue({ rows: ["dummy"] }),
  tryConnect: jest.fn().mockResolvedValue(true),
};
jest.mock('pg', () => {
  return {
    Client: jest.fn(() => mockClient)
  };
});
const pg = await import ('pg');

import { SecretsManager } from "@aws-sdk/client-secrets-manager";


jest.mock('@aws-sdk/client-secrets-manager', () => {
    return {
      __esModule: true,
      SecretsManager: jest.fn(() => ({
        getSecretValue:  jest.fn().mockResolvedValue({
            SecretString: JSON.stringify({
              username: 'test',
              password: 'test',
            }),
          }),
      })),
    };
  });

  const { S3Client, GetObjectCommand } = await import ("@aws-sdk/client-s3");
  const report_event_Template = await import('../sample-events/example_scheduled_reports.json');

  const mockPipe = jest.fn().mockImplementation(async function* () {
    yield report_event_Template.default
  });  
  const res_Success = {
    Body : {
      transformToString : jest.fn().mockResolvedValue(JSON.stringify(report_event_Template.default)),
      pipe: jest.fn().mockImplementation(async function* () {yield report_event_Template.default}),
      ...report_event_Template.default
    }
  };


  jest.mock('@aws-sdk/client-s3', () => {
    return {
      __esModule: true,
      S3Client: jest.fn(() => ({
        send : jest.fn().mockResolvedValue(res_Success)
      })),
      GetObjectCommand : jest.fn(() => {})
    }
    
    });

    const eventbridge_event_Template = await import('../sample-events/example_eventbridge_s3_put.json');
    let env_backup;
    let lambda;
    let successful_event;
    let report_event;
describe('Update scheduled reports tests', ()=> {

  beforeAll( async () => {
    //Set static variables
            env_backup = process.env;
            process.env = lambda_env;
 
             lambda = await import('../../src/index.mjs');
        });
    
        afterAll( () => {
            // Restore env variables.
            process.env = env_backup;
    
        });
    
        beforeEach( async () => {     
          // Reset sample events.
          successful_event = structuredClone(eventbridge_event_Template.default);
          successful_event.detail.bucket.name = "report-bucket"
          successful_event.detail.object.key = "ODS_Queue"
          report_event = structuredClone(report_event_Template.default);

      
          S3Client.prototype.send.mockResolvedValue(res_Success)
        });
        
        test('One Line In Record Info', async () => {
          const lambda_res = await lambda.handler(successful_event, {awsRequestId : "sjhdfsdkjhfsld"});
        });

        test('Multiple Lines in Record Info', async () => {
          res_Success.Body.pipe = jest.fn().mockImplementationOnce(async function* () {
            yield {
                "info": {
                    "lines" : 2
                },
                "record": ["dummy"]
            }
          });
          mockClient.query.mockResolvedValueOnce({ rows: ["dummy"] });
          mockClient.query.mockResolvedValue({rowCount: 1});  
          const lambda_res = await lambda.handler(successful_event, {awsRequestId : "sjhdfsdkjhfsld"});
        });

        test('Multiple Lines in Record Info with Update Failure', async () => {
          res_Success.Body.pipe = jest.fn().mockImplementationOnce(async function* () {
            yield {
                "info": {
                    "lines" : 2
                },
                "record": ["dummy"]
            }
          });
          mockClient.query.mockResolvedValueOnce({ rows: ["dummy"] });
          mockClient.query.mockResolvedValue({rowCount: 2});  
          await expect(lambda.handler(successful_event, {awsRequestId : "sjhdfsdkjhfsld"}))
          .rejects
          .toThrow("Update Processing records failure, trying updating ODS_Queue to SUCCEEDED but current status is not PROCESSING.cwUrl= https://us-west-1.console.aws.amazon.com/cloudwatch/home?region=us-west-1#logsV2:log-groups/log-group/test/log-events/testStream$3FfilterPattern$3D$2525sjhdfsdkjhfsld$2525");
        });

        test('Multiple Lines in Record Info with Many Fields', async () => {
          res_Success.Body.pipe = jest.fn().mockImplementationOnce(async function* () {
            yield {
                "info": {
                    "lines" : 2
                },
                "record": ["", "1", "50%"]
            }
          });
          mockClient.query.mockResolvedValueOnce({ rows: ["", "1", "50%"] });
          mockClient.query.mockResolvedValue({rowCount: 1});  
          const lambda_res = await lambda.handler(successful_event, {awsRequestId : "sjhdfsdkjhfsld"});
        });

        test('Missing Column In Schema', async () => {
          res_Success.Body.pipe = jest.fn().mockImplementationOnce(async function* () {
            yield {
                "info": {
                    "lines" : 1
                },
                "record": ["dummy"]
            }
          });
          mockClient.query.mockResolvedValueOnce({});
          mockClient.query.mockResolvedValueOnce({ rows: ["missing"] });
          mockClient.query.mockResolvedValue({rowCount: 1});
          await expect(lambda.handler(successful_event, {awsRequestId : "sjhdfsdkjhfsld"}))
          .rejects
          .toThrow("Missing Column: Table=ods_oob_agg_queue, Missing columns=dummycwUrl= https://us-west-1.console.aws.amazon.com/cloudwatch/home?region=us-west-1#logsV2:log-groups/log-group/test/log-events/testStream$3FfilterPattern$3D$2525sjhdfsdkjhfsld$2525");
        });

        test("dbClient Insert Error", async () => {
          mockClient.query.mockRejectedValueOnce(new Error("Connection Error"));
          const lambda_res = await lambda.handler(successful_event, {awsRequestId : "sjhdfsdkjhfsld"});
          expect(lambda_res).toEqual({"LambdaSuccess":false, "message":{"key_name":"ODS_Queue","error":"s3File=ODS_Queue Already present in table ods_oob_csv_processing_record, skipping"}})
        });
 
        /* Todo create sample csv.
            test('Successful Test', async () => {
        
                
                const lambda_res = await lambda.handler(successful_event);
        
                expect(lambda_res).toEqual({ "LambdaSuccess": false, "message": "Eventbridge event type unmatched: event.source=undefined, event.detail-type=undefined",})
            })


            test('No pattern match Test', async () => {
        
                
              const lambda_res = await lambda.handler(successful_event);
      
              expect(lambda_res).toEqual({ "LambdaSuccess": false, "message": "Eventbridge event type unmatched: event.source=undefined, event.detail-type=undefined",})
          })

          test('Multiple pattern match Test', async () => {
        
                
            const lambda_res = await lambda.handler(successful_event);
    
            expect(lambda_res).toEqual({ "LambdaSuccess": false, "message": "Eventbridge event type unmatched: event.source=undefined, event.detail-type=undefined",})
        })

        test('Duplicate key already in record Test', async () => {
        
                
          const lambda_res = await lambda.handler(successful_event);
  
          expect(lambda_res).toEqual({ "LambdaSuccess": false, "message": "Eventbridge event type unmatched: event.source=undefined, event.detail-type=undefined",})
      })

      test('Single Line Record Test', async () => {
        
                
        const lambda_res = await lambda.handler(successful_event);

        expect(lambda_res).toEqual({ "LambdaSuccess": false, "message": "Eventbridge event type unmatched: event.source=undefined, event.detail-type=undefined",})
    })
      
    test('Multi Line Record Test', async () => {
        
                
      const lambda_res = await lambda.handler(successful_event);

      expect(lambda_res).toEqual({ "LambdaSuccess": false, "message": "Eventbridge event type unmatched: event.source=undefined, event.detail-type=undefined",})
  })*/
})